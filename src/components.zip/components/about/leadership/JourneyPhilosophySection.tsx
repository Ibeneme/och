"use client";

import { Award, Heart } from "lucide-react";
import { useLanguage } from "@/src/context/LanguageContext";
import content from "@/src/locales/about-us/leadership.json";

export default function JourneyPhilosophySection() {
  const { language } = useLanguage();
  const t = content[language as "en" | "es"] || content.en;

  const MILESTONES = [
    {
      year: "2003",
      tag: "(begin)",
      kicker: "career /",
      kickerRest: "nursing begins",
      panel: "dark",
      body: "Angela began her professional nursing career, cultivating deep expertise in clinical care, patient advocacy, and healthcare administration over more than two decades.",
      footer: t.milestone1Footer,
    },
    {
      year: "2010",
      tag: "(found)",
      kicker: "founding /",
      kickerRest: "jacop healthcare",
      panel: "gold",
      body: "Driven by a vision for more personalized, compassionate care delivered where people feel most comfortable, Angela founded JACOP Healthcare Services, Inc.",
      footer: t.milestone2Footer,
    },
    {
      year: "2026",
      tag: "(today)",
      kicker: "evolution /",
      kickerRest: "one community",
      panel: "dark",
      body: "Carrying the JACOP legacy forward, One Community Home Health was established as its DBA — continuing exceptional skilled nursing and therapy across the DFW Metroplex.",
      footer: t.milestone3Footer,
    },
  ];

  return (
    <div className="space-y-24 min-w-0 p-6">
      {/* Journey Section */}
      <section id="journey" className="scroll-mt-24 space-y-10">
        <div className="max-w-2xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#F3ECDC] text-[#0A2140] text-xs font-semibold tracking-wider uppercase">
            <Award className="w-4 h-4 text-[#C89B3C]" /> {t.journeyEyebrow}
          </div>
          <h2 className="ohh-serif text-3xl sm:text-4xl font-semibold text-[#0A2140] leading-tight tracking-tight">
            {t.journeyTitle}
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-px bg-[#EFE8D8] rounded-3xl overflow-hidden border border-[#EFE8D8]">
          {MILESTONES.map((m) => (
            <div key={m.year} className="bg-white flex flex-col">
              <div
                className={
                  m.panel === "dark"
                    ? "bg-[#0A2140] text-white px-7 pt-9 pb-7 relative"
                    : "bg-[#E4B95A] text-[#0A2140] px-7 pt-9 pb-7 relative"
                }
                style={{
                  clipPath:
                    "polygon(0 0, 100% 0, 100% 100%, 32px 100%, 0 calc(100% - 32px))",
                }}
              >
                <div className="flex items-start justify-between">
                  <span
                    className={`ohh-serif text-5xl md:text-6xl font-semibold tracking-tighter leading-none ${
                      m.panel === "dark" ? "text-[#E4B95A]" : "text-[#0A2140]"
                    }`}
                  >
                    {m.year}
                  </span>
                  <span
                    className={`text-xs uppercase mt-2 ${
                      m.panel === "dark" ? "text-slate-300" : "text-[#0A2140]/70"
                    }`}
                  >
                    {m.tag}
                  </span>
                </div>
                <div
                  className={`mt-6 flex items-baseline gap-1.5 text-xs uppercase tracking-wide ${
                    m.panel === "dark" ? "text-slate-300" : "text-[#0A2140]/80"
                  }`}
                >
                  <span
                    className={
                      m.panel === "dark" ? "text-[#E4B95A]" : "font-semibold"
                    }
                  >
                    {m.kicker}
                  </span>
                  <span>{m.kickerRest}</span>
                </div>
              </div>
              <div className="px-7 py-7 flex-1 flex flex-col justify-between space-y-5">
                <p className="text-[#3A4657] text-sm leading-relaxed">{m.body}</p>
                <div className="pt-3 border-t border-[#F0EBDD] text-[11px] font-bold uppercase tracking-wider text-[#8A7B5C]">
                  {m.footer}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Leadership Philosophy Section */}
      <section id="philosophy" className="scroll-mt-24 space-y-10">
        <div className="max-w-2xl space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#F3ECDC] text-[#0A2140] text-xs font-semibold uppercase tracking-wider">
            <Heart className="w-3.5 h-3.5 text-[#C89B3C]" /> {t.philEyebrow}
          </div>
          <h2 className="ohh-serif text-3xl sm:text-4xl font-semibold text-[#0A2140] tracking-tight">
            {t.philTitle}
          </h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          <div className="lg:col-span-3 bg-[#0A2140] rounded-3xl p-9 lg:p-11 relative overflow-hidden text-white flex flex-col justify-between min-h-[280px]">
            <div className="absolute -top-16 -right-16 w-56 h-56 bg-[#E4B95A]/10 rounded-full blur-3xl pointer-events-none" />
            <div className="relative z-10 space-y-4">
              <div className="w-12 h-12 rounded-full bg-white/10 text-[#E4B95A] font-bold flex items-center justify-center text-sm">
                01
              </div>
              <h3 className="ohh-serif text-2xl lg:text-3xl font-semibold leading-snug">
                {t.phil1Title}
              </h3>
            </div>
            <p className="relative z-10 text-slate-300 text-[15px] leading-relaxed pt-6 border-t border-white/10 mt-6">
              {t.phil1Desc}
            </p>
          </div>

          <div className="lg:col-span-2 bg-white rounded-3xl p-9 border border-[#EFE8D8] flex flex-col justify-between space-y-5">
            <div className="w-12 h-12 rounded-full bg-[#F3ECDC] text-[#C89B3C] font-bold flex items-center justify-center text-sm">
              02
            </div>
            <div className="space-y-3">
              <h3 className="ohh-serif text-xl font-semibold text-[#0A2140]">
                {t.phil2Title}
              </h3>
              <p className="text-[#5B6B7C] text-[15px] leading-relaxed">
                {t.phil2Desc}
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}