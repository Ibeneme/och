"use client";

import {
  BookOpen,
  ShieldAlert,
  Users,
  Wallet,
  Clock,
  ShieldCheck,
  AlertTriangle,
  ExternalLink,
  HeartPulse,
  Briefcase,
  ClipboardList,
  Pill,
  Lock,
  Scale,
} from "lucide-react";
import { useLanguage } from "@/src/context/LanguageContext";
import content from "@/src/locales/resources/employee-resources.json";

export default function EmployeeResourcesPage() {
  const { language } = useLanguage();
  const t = content[language as "en" | "es"] || content.en;

  const escalationMatrix = [
    {
      label: "Life-threatening emergency",
      desc: "Call 911 immediately for severe life-threatening medical emergencies.",
      action: "Dial 911",
      tone: "emergency",
    },
    {
      label: "Urgent clinical need",
      desc: "Use the 24/7 on-call clinical extension for immediate patient needs.",
      action: "On-call line",
      tone: "urgent",
    },
    {
      label: "Routine incidents",
      desc: "Submit official logs through standard agency reporting workflows.",
      action: "Documentation portal",
      tone: "routine",
    },
    {
      label: "HR & payroll",
      desc: "Contact the administrative desk during standard operating hours.",
      action: "Mon–Fri, 9 AM–5 PM",
      tone: "routine",
    },
    {
      label: "Compliance",
      desc: "Report ethics, safety, or confidentiality concerns directly.",
      action: "Compliance officer",
      tone: "routine",
    },
  ];

  const evvSteps = [
    {
      icon: Clock,
      title: "Clock in / out",
      desc: "Use the official HHAeXchange mobile application or telephony system at the exact location of service delivery.",
    },
    {
      icon: ShieldCheck,
      title: "EVV reminders",
      desc: "Keep device GPS services enabled. Confirm visit tasks and applicable service codes before final submission.",
    },
    {
      icon: AlertTriangle,
      title: "Missed visits",
      desc: "If a recording error or missed check-in happens, notify administration immediately and submit a manual adjustment ticket.",
    },
  ];

  const incidentTypes = [
    {
      icon: HeartPulse,
      title: "Patient incidents",
      desc: "Report sudden clinical changes, falls, or unexpected adverse events immediately to clinical supervision.",
    },
    {
      icon: Briefcase,
      title: "Employee injuries",
      desc: "Report workplace injuries sustained on duty directly to HR and management immediately for proper documentation.",
    },
    {
      icon: ShieldAlert,
      title: "Safety hazards",
      desc: "Identify and report environmental risks in client homes or workplaces threatening staff or client well-being.",
    },
    {
      icon: ClipboardList,
      title: "Missed visits",
      desc: "Document and report any unfulfilled or missed visits immediately to ensure unbroken continuity of care.",
    },
    {
      icon: Pill,
      title: "Medication flags",
      desc: "Report discrepancies, missed doses, or adverse reactions involving medications instantly to clinical leadership.",
    },
    {
      icon: AlertTriangle,
      title: "Abuse & neglect",
      desc: "Suspected abuse, exploitation, or neglect must be reported instantly to state authorities and agency compliance.",
    },
    {
      icon: Lock,
      title: "Privacy & HIPAA",
      desc: "Report potential privacy breaches, unauthorized disclosures, or data vulnerabilities without delay.",
    },
    {
      icon: Scale,
      title: "Ethics & billing",
      desc: "Voice concerns regarding billing precision, regulatory standards, or unethical practices securely.",
    },
  ];

  const toneStyles: Record<string, { bg: string; label: string }> = {
    emergency: { bg: "bg-[#3E1424]", label: "text-[#F3A8C0]" },
    urgent: { bg: "bg-[#3E2A14]", label: "text-[#F0C48A]" },
    routine: { bg: "bg-white/5", label: "text-white/80" },
  };

  return (
    <main className="min-h-screen bg-white text-[#3A4657] ohh-sans">
      {/* ===== Hero ===== */}
      <section className="relative overflow-hidden bg-[#0A2140] text-white pt-24 pb-20 lg:pt-28 lg:pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid lg:grid-cols-12 gap-12 items-center">
            <div className="lg:col-span-7">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/10 text-[#E4B95A] font-semibold text-xs tracking-wider uppercase mb-8">
                <span className="w-2 h-2 rounded-full bg-[#E4B95A] animate-pulse" />
                {t.badge}
              </div>

              <h1 className="ohh-serif text-4xl sm:text-5xl lg:text-6xl font-semibold leading-[1.1] mb-6 tracking-tight">
                {t.titleMain} <span className="text-[#E4B95A]">{t.titleHighlight}</span>
              </h1>

              <p className="text-lg text-white/70 max-w-xl leading-relaxed mb-10">
                {t.description}
              </p>

              <div className="flex flex-wrap gap-4">
                <a
                  href="#handbook"
                  className="inline-flex items-center gap-2 px-7 py-3.5 bg-[#E4B95A] hover:bg-[#D9A93F] text-[#0A2140] font-bold rounded-full transition-colors"
                >
                  <BookOpen size={16} />
                  {t.handbookBtn}
                </a>
                <a
                  href="#reporting"
                  className="inline-flex items-center gap-2 px-7 py-3.5 bg-white/10 hover:bg-white/15 text-white font-semibold rounded-full transition-colors"
                >
                  <ShieldAlert size={16} />
                  {t.protocolsBtn}
                </a>
              </div>
            </div>

            <div className="lg:col-span-5 bg-white/5 rounded-3xl p-8 space-y-5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-widest text-[#E4B95A]">
                  Quick status
                </span>
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
              </div>
              <div className="space-y-3 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-white/50">{t.officeLabel}</span>
                  <span className="text-white font-medium">{t.hqText}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-white/50">{t.evvLabel}</span>
                  <span className="text-emerald-400 font-medium">{t.evvStatus}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-white/50">{t.supportLabel}</span>
                  <span className="text-[#E4B95A] font-medium">{t.supportStatus}</span>
                </div>
              </div>
              <p className="text-white/40 text-xs leading-relaxed pt-2">
                {t.confidentialNotice}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ===== Escalation Matrix Strip ===== */}
      <section className="bg-[#0A2140] py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <h2 className="ohh-serif text-lg sm:text-xl font-semibold text-white">
              {t.matrixHeading}
            </h2>
            <span className="text-white/40 text-xs font-medium hidden sm:inline">
              {t.matrixCount}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {escalationMatrix.map((item, idx) => {
              const tone = toneStyles[item.tone];
              return (
                <div
                  key={item.label}
                  className={`${tone.bg} p-6 rounded-2xl flex flex-col justify-between`}
                >
                  <div>
                    <span className="text-[11px] font-bold text-white/40 block mb-2">
                      {String(idx + 1).padStart(2, "0")}
                    </span>
                    <span className={`${tone.label} font-bold block mb-2 text-sm leading-snug`}>
                      {item.label}
                    </span>
                    <p className="text-white/60 text-xs leading-relaxed">{item.desc}</p>
                  </div>
                  <div className={`${tone.label} mt-5 text-[11px] font-semibold uppercase tracking-wide`}>
                    {item.action}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ===== Employee Handbook ===== */}
      <section id="handbook" className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-12 gap-12 items-center">
            <div className="lg:col-span-7 space-y-6">
              <span className="inline-block text-xs font-bold uppercase tracking-widest text-[#C89B3C] bg-[#F3ECDC] px-3.5 py-1.5 rounded-full">
                {t.handbookBadge}
              </span>
              <h2 className="ohh-serif text-3xl sm:text-4xl font-semibold text-[#0A2140]">
                {t.handbookTitle}
              </h2>
              <p className="text-[#5B6B7C] leading-relaxed">
                {t.handbookDesc}
              </p>

              <div className="bg-[#FBF8F2] p-6 rounded-2xl space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-[#8A93A0]">{t.effDate}</span>
                  <span className="text-[#0A2140] font-semibold">{t.effVal}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#8A93A0]">{t.statusLabel}</span>
                  <span className="text-[#C89B3C] font-semibold">{t.statusVal}</span>
                </div>
              </div>

              <div className="flex flex-wrap gap-4 pt-2">
                <button
                  onClick={() => alert("Handbook download initialized.")}
                  className="inline-flex items-center gap-2 px-7 py-3.5 bg-[#0A2140] hover:bg-[#123258] text-white font-bold rounded-full transition-colors"
                >
                  {t.downloadPdf}
                </button>
                <button
                  onClick={() => alert("Acknowledgment form instructions dispatched via HR.")}
                  className="inline-flex items-center gap-2 px-7 py-3.5 bg-[#F3ECDC] hover:bg-[#EADFC2] text-[#0A2140] font-semibold rounded-full transition-colors"
                >
                  {t.ackInfo}
                </button>
              </div>
            </div>

            <div className="lg:col-span-5 bg-[#0A2140] text-white p-10 rounded-3xl flex flex-col justify-between">
              <div>
                <span className="inline-block text-xs font-bold uppercase tracking-widest text-[#E4B95A] bg-white/10 px-3 py-1.5 rounded-full mb-6">
                  {t.ackNoticeBadge}
                </span>
                <h3 className="ohh-serif text-2xl font-semibold mb-4">
                  {t.ackNoticeTitle}
                </h3>
                <p className="text-white/70 text-sm leading-relaxed">
                  {t.ackNoticeDesc}
                </p>
              </div>
              <p className="text-white/40 text-xs uppercase tracking-wide pt-8 mt-8">
                {t.directInquiries}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* ===== HR & Payroll ===== */}
      <section className="py-24 bg-[#FBF8F2]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mb-16">
            <span className="inline-block text-xs font-bold uppercase tracking-widest text-[#C89B3C] bg-white px-3.5 py-1.5 rounded-full mb-4">
              {t.hrBadge}
            </span>
            <h2 className="ohh-serif text-3xl sm:text-4xl font-semibold text-[#0A2140] mb-4">
              {t.hrTitle}
            </h2>
            <p className="text-[#5B6B7C]">{t.hrDesc}</p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {[
              {
                icon: Users,
                title: t.hrDesk,
                ext: "972-325-1598 ext. HR",
                email: "hr@onechh.com",
              },
              {
                icon: Wallet,
                title: t.payrollDesk,
                ext: "972-325-1598 ext. Payroll",
                email: "payroll@onechh.com",
              },
            ].map((desk) => (
              <div
                key={desk.title}
                className="bg-white p-8 sm:p-10 rounded-3xl flex flex-col justify-between"
              >
                <div>
                  <div className="w-11 h-11 rounded-2xl bg-[#F3ECDC] text-[#0A2140] flex items-center justify-center mb-5">
                    <desk.icon size={20} />
                  </div>
                  <h3 className="text-lg font-bold text-[#0A2140] mb-5">
                    {desk.title}
                  </h3>
                  <div className="space-y-3 text-sm mb-6">
                    <div className="flex justify-between">
                      <span className="text-[#8A93A0]">{t.phoneLabel}</span>
                      <span className="text-[#0A2140] font-semibold">{desk.ext}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#8A93A0]">{t.emailLabel}</span>
                      <span className="text-[#C89B3C] font-medium">{desk.email}</span>
                    </div>
                  </div>
                  <div className="p-4 bg-[#FBF8F2] rounded-xl text-xs text-[#5B6B7C]">
                    <span className="text-[#8A93A0] block mb-1">{t.operatingWindow}</span>
                    {t.windowTime}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== HHAeXchange & EVV ===== */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-[#0A2140] p-10 sm:p-16 rounded-3xl">
            <div className="max-w-3xl mb-12">
              <span className="inline-block text-xs font-bold uppercase tracking-widest text-[#E4B95A] bg-white/10 px-3.5 py-1.5 rounded-full mb-4">
                {t.evvBadge}
              </span>
              <h2 className="ohh-serif text-3xl sm:text-4xl font-semibold text-white mb-4">
                {t.evvTitle}
              </h2>
              <p className="text-white/60 text-sm leading-relaxed">
                {t.evvDesc}
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-6 mb-12">
              {evvSteps.map((step) => (
                <div key={step.title} className="bg-white/5 p-8 rounded-2xl">
                  <div className="w-10 h-10 rounded-full bg-white/10 text-[#E4B95A] flex items-center justify-center mb-4">
                    <step.icon size={18} />
                  </div>
                  <h4 className="font-semibold text-white mb-2 text-sm">{step.title}</h4>
                  <p className="text-xs text-white/60 leading-relaxed">{step.desc}</p>
                </div>
              ))}
            </div>

            <div className="flex flex-wrap items-center justify-between gap-6 p-8 bg-[#E4B95A]/10 rounded-2xl">
              <div>
                <h4 className="font-semibold text-white text-base">
                  {t.portalTitle}
                </h4>
                <p className="text-xs text-white/60 mt-1">{t.portalDesc}</p>
              </div>
              <a
                href="https://ha.hhaexchange.com/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-7 py-3.5 bg-[#E4B95A] hover:bg-[#D9A93F] text-[#0A2140] font-bold rounded-full transition-colors text-sm shrink-0"
              >
                {t.launchPortal}
                <ExternalLink size={15} />
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* ===== Incident Reporting & Compliance ===== */}
      <section id="reporting" className="py-24 bg-[#FBF8F2]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mb-16">
            <span className="inline-block text-xs font-bold uppercase tracking-widest text-[#C89B3C] bg-white px-3.5 py-1.5 rounded-full mb-4">
              {t.safetyBadge}
            </span>
            <h2 className="ohh-serif text-3xl sm:text-4xl font-semibold text-[#0A2140] mb-4">
              {t.safetyTitle}
            </h2>
            <p className="text-[#5B6B7C]">{t.safetyDesc}</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5 mb-16">
            {incidentTypes.map((item) => (
              <div
                key={item.title}
                className="bg-white p-7 rounded-2xl hover:bg-white/70 transition-colors"
              >
                <div className="w-10 h-10 rounded-full bg-[#F3ECDC] text-[#0A2140] flex items-center justify-center mb-4">
                  <item.icon size={18} />
                </div>
                <h4 className="font-semibold text-[#0A2140] mb-2 text-sm">{item.title}</h4>
                <p className="text-xs text-[#5B6B7C] leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>

          <div className="bg-[#0A2140] text-white p-10 sm:p-12 rounded-3xl">
            <h3 className="ohh-serif text-lg font-semibold mb-6 text-[#E4B95A]">
              {t.emergencyRefTitle}
            </h3>
            <div className="grid sm:grid-cols-3 gap-6 text-sm">
              <div className="bg-[#3E1424] p-6 rounded-2xl space-y-2">
                <strong className="text-[#F3A8C0] block text-sm font-semibold">
                  {t.medEmerg}
                </strong>
                <p className="text-white/60 leading-relaxed text-xs">
                  {t.medEmergText}
                </p>
              </div>
              <div className="bg-[#3E2A14] p-6 rounded-2xl space-y-2">
                <strong className="text-[#F0C48A] block text-sm font-semibold">
                  {t.urgentClin}
                </strong>
                <p className="text-white/60 leading-relaxed text-xs">
                  {t.urgentClinText}
                </p>
              </div>
              <div className="bg-white/5 p-6 rounded-2xl space-y-2">
                <strong className="text-white block text-sm font-semibold">
                  {t.routineMatters}
                </strong>
                <p className="text-white/60 leading-relaxed text-xs">
                  {t.routineMattersText}
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}