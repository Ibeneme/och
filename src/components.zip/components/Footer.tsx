"use client";

import Link from "next/link";
import {
  HeartHandshake,
  Phone,
  MapPin,
  Clock,
  ShieldCheck,
  Users,
  ArrowUpRight,
} from "lucide-react";
import { useLanguage } from "@/src/context/LanguageContext";
import footerContent from "@/src/locales/footer/footer.json";
import { siteConfig } from "@/src/constants/siteConfig";

const FooterLinkColumn = ({
  title,
  links,
  language,
}: {
  title: string;
  links: { label: { en: string; es: string }; href: string }[];
  language: "en" | "es";
}) => (
  <div>
    <h4 className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#E4B95A]/90 mb-5">
      {title}
    </h4>
    <ul className="space-y-3">
      {links.map((link) => (
        <li key={link.href + link.label.en}>
          <Link
            href={link.href}
            className="group inline-flex items-center gap-1.5 text-[13.5px] text-white/65 hover:text-white transition-colors duration-200"
          >
            <span className="relative">
              {link.label[language] || link.label.en}
              <span className="absolute left-0 -bottom-0.5 h-px w-0 bg-[#E4B95A] transition-all duration-300 group-hover:w-full" />
            </span>
          </Link>
        </li>
      ))}
    </ul>
  </div>
);

export default function Footer() {
  const { language } = useLanguage();
  const lang = (language === "es" ? "es" : "en") as "en" | "es";

  const infoItems = [
    {
      icon: MapPin,
      label: footerContent.office.locationLabel[lang],
      lines: [siteConfig.address.full, siteConfig.address.street],
      accent: siteConfig.address.note[lang],
    },
    {
      icon: Clock,
      label: footerContent.office.hoursLabel[lang],
      lines: [siteConfig.hours[lang]],
      accent: footerContent.office.hoursNote[lang],
    },
    {
      icon: ShieldCheck,
      label: footerContent.office.coverageLabel[lang],
      lines: [footerContent.office.coverageLines[lang]],
      accent: footerContent.office.coverageNote[lang],
    },
    {
      icon: Users,
      label: footerContent.office.portalsLabel[lang],
      lines: [footerContent.office.portalsLines[lang]],
      accent: footerContent.office.portalsNote[lang],
    },
  ];

  return (
    <footer className="w-full bg-[#07162C] text-white border-t border-[#102B4E] relative overflow-hidden">
      <svg
        className="absolute top-0 left-0 w-full h-24 opacity-[0.08] pointer-events-none"
        viewBox="0 0 1200 100"
        preserveAspectRatio="none"
        aria-hidden="true"
      >
        <path
          d="M0,60 C150,10 300,90 450,50 C600,10 750,90 900,45 C1000,15 1100,55 1200,30"
          fill="none"
          stroke="#E4B95A"
          strokeWidth="2"
          strokeDasharray="1 10"
          strokeLinecap="round"
        />
      </svg>

      <div className="relative max-w-7xl mx-auto px-6 md:px-12 pt-14 pb-12 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-8 border-b border-white/10">
        <div className="max-w-xl">
          <p className="text-[11px] font-semibold uppercase tracking-[0.2em] text-[#E4B95A] mb-3">
            {footerContent.banner.title[lang]}
          </p>
          <h3 className="text-2xl md:text-3xl font-semibold leading-snug text-white">
            {footerContent.banner.subtitle[lang]}
          </h3>
        </div>
        <div className="flex flex-col sm:flex-row gap-3 shrink-0">
          <a
            href={`tel:${siteConfig.contact.phoneTel}`}
            className="inline-flex items-center justify-center gap-2 border border-white/15 hover:border-white/30 bg-white/5 hover:bg-white/10 text-white text-sm font-semibold py-3.5 px-6 rounded-full transition-colors"
          >
            <Phone size={16} className="text-[#E4B95A] shrink-0" />
            {siteConfig.contact.phone}
          </a>
          <Link
            href="/contact"
            className="inline-flex items-center justify-center gap-2 bg-yellow-400 hover:bg-[#D9A93F] text-[#07162C] text-sm font-bold py-3.5 px-6 rounded-full transition-colors"
          >
            <HeartHandshake size={16} />
            {footerContent.buttons.requestConsultation[lang]}
          </Link>
        </div>
      </div>

      <div className="relative max-w-7xl mx-auto px-6 md:px-12 py-16 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-12 gap-x-8 gap-y-12">
        <div className="lg:col-span-3">
          <FooterLinkColumn
            title={footerContent.columns.navigation[lang]}
            links={footerContent.navLinks}
            language={lang}
          />
        </div>
        <div className="lg:col-span-3">
          <FooterLinkColumn
            title={footerContent.columns.clinicalServices[lang]}
            links={footerContent.clinicalLinks}
            language={lang}
          />
        </div>
        <div className="lg:col-span-3">
          <FooterLinkColumn
            title={footerContent.columns.supportiveCare[lang]}
            links={footerContent.supportiveLinks}
            language={lang}
          />
        </div>

        <div className="lg:col-span-3">
          <h4 className="text-[11px] font-semibold uppercase tracking-[0.18em] text-[#E4B95A]/90 mb-5">
            {footerContent.columns.officeInfo[lang]}
          </h4>
          <div className="space-y-4 mb-6">
            {infoItems.map(({ icon: Icon, label, lines, accent }) => (
              <div key={label} className="flex items-start gap-3">
                <div className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-white/5">
                  <Icon size={14} className="text-[#E4B95A]" />
                </div>
                <div>
                  <p className="text-[11px] font-semibold uppercase tracking-wider text-white/50">
                    {label}
                  </p>
                  {lines.map((line) => (
                    <p
                      key={line}
                      className="text-[13.5px] text-white/80 leading-snug"
                    >
                      {line}
                    </p>
                  ))}
                  <p className="text-[12px] text-[#E4B95A] font-medium mt-0.5">
                    {accent}
                  </p>
                </div>
              </div>
            ))}
          </div>
          <Link
            href="/contact"
            className="inline-flex items-center gap-1.5 text-[13px] font-semibold text-white hover:text-[#E4B95A] transition-colors"
          >
            {footerContent.office.directionsLink[lang]}
            <ArrowUpRight size={14} />
          </Link>
        </div>
      </div>

      <div className="relative max-w-7xl mx-auto px-6 md:px-12 pb-10 overflow-hidden">
        <h2 className="text-[13vw] lg:text-[9vw] font-bold tracking-tighter leading-none text-white select-none whitespace-nowrap [-webkit-text-stroke:1px_rgba(255,255,255,0.95)] [-webkit-text-fill-color:transparent] lg:[-webkit-text-fill-color:white] lg:[-webkit-text-stroke:0]">
          {siteConfig.name}
        </h2>
      </div>

      <div className="relative max-w-7xl mx-auto px-6 md:px-12 py-6 border-t border-white/10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 text-xs text-white/45">
        <div className="space-y-1">
          <p>{footerContent.legal.copyright[lang]}</p>
          <p className="text-[11px] text-white/35">
            {footerContent.legal.operatedBy[lang]}
          </p>
        </div>
        <div className="flex items-center gap-6">
          <Link href="/contact" className="hover:text-white transition-colors">
            {footerContent.legal.privacy[lang]}
          </Link>
          <Link href="/contact" className="hover:text-white transition-colors">
            {footerContent.legal.terms[lang]}
          </Link>
          <Link href="/contact" className="hover:text-white transition-colors">
            {footerContent.legal.accessibility[lang]}
          </Link>
        </div>
      </div>
    </footer>
  );
}