"use client";

import React from "react";
import Link from "next/link";
import { useLanguage } from "@/src/context/LanguageContext";
import translationsJson from "@/src/locales/insurance/insurance-payment.json";
import {
  ShieldCheck,
  Phone,
  ArrowRight,
  CheckCircle2,
  Award,
  Layers,
  SlidersHorizontal,
  Info,
  ShieldAlert,
} from "lucide-react";
import { siteConfig } from "@/src/constants/siteConfig";

export interface InsuranceItem {
  key: string;
  bgClass: string;
  textClass: string;
  badgeBgClass: string;
}

export const insuranceLines: InsuranceItem[] = [
  {
    key: "ins.medicare",
    bgClass: "bg-[#1B2333]",
    textClass: "text-[#F5C77E]",
    badgeBgClass: "bg-white/10 text-[#F5C77E]",
  },
  {
    key: "ins.medicaid",
    bgClass: "bg-[#0F2A4D]",
    textClass: "text-[#A9C6F0]",
    badgeBgClass: "bg-white/10 text-[#A9C6F0]",
  },
  {
    key: "ins.molina",
    bgClass: "bg-[#211B3E]",
    textClass: "text-[#B9AEFF]",
    badgeBgClass: "bg-white/10 text-[#B9AEFF]",
  },
  {
    key: "ins.superior",
    bgClass: "bg-[#3E1424]",
    textClass: "text-[#F3A8C0]",
    badgeBgClass: "bg-white/10 text-[#F3A8C0]",
  },
  {
    key: "ins.wellpoint",
    bgClass: "bg-[#17324F]",
    textClass: "text-[#8FB8E0]",
    badgeBgClass: "bg-white/10 text-[#8FB8E0]",
  },
  {
    key: "ins.aetna",
    bgClass: "bg-[#331B3E]",
    textClass: "text-[#E3AEE8]",
    badgeBgClass: "bg-white/10 text-[#E3AEE8]",
  },
  {
    key: "ins.va",
    bgClass: "bg-[#14263E]",
    textClass: "text-[#9FC7F5]",
    badgeBgClass: "bg-white/10 text-[#9FC7F5]",
  },
  {
    key: "ins.private",
    bgClass: "bg-[#3E2A14]",
    textClass: "text-[#F0C48A]",
    badgeBgClass: "bg-white/10 text-[#F0C48A]",
  },
];

export default function InsurancePaymentOptionsPage() {
  const { language } = useLanguage();

  const t = (key: string): string => {
    if (translationsJson[key] && translationsJson[key][language as "en" | "es"]) {
      return translationsJson[key][language as "en" | "es"];
    }
    return key;
  };

  return (
    <main className="min-h-screen bg-[#FBF8F2] text-[#3A4657] ohh-sans">
      {/* ===== Hero Section ===== */}
      <section className="relative overflow-hidden pt-12 pb-16 lg:pt-20 lg:pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-12 gap-12 items-center">
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#F3ECDC] text-[#0A2140] font-semibold text-xs tracking-wider uppercase">
                <span className="w-2 h-2 rounded-full bg-[#C89B3C]" />
                {t("insurance.badge")}
              </div>

              <h1 className="ohh-serif text-4xl sm:text-5xl lg:text-6xl font-semibold text-[#0A2140] tracking-tight leading-[1.1]">
                {t("insurance.title.part1")}{" "}
                <span className="text-[#C89B3C]">
                  {t("insurance.title.part2")}
                </span>
              </h1>

              <p className="text-base sm:text-lg text-[#5B6B7C] leading-relaxed">
                {t("insurance.description")}
              </p>

              <div className="flex flex-col sm:flex-row gap-4 pt-2">
                <a
                  href={`tel:${siteConfig.contact.phoneTel}`}
                  className="inline-flex items-center justify-center gap-2 px-7 py-3.5 bg-[#0A2140] hover:bg-[#123258] text-[#E4B95A] font-bold rounded-full transition-colors"
                >
                  <Phone size={16} />
                  <span>Call {siteConfig.contact.phone}</span>
                </a>
                <Link
                  href="/contact"
                  className="inline-flex items-center justify-center gap-2 px-7 py-3.5 bg-[#F3ECDC] hover:bg-[#EADFC2] text-[#0A2140] font-semibold rounded-full transition-colors"
                >
                  <span>{t("insurance.contactBtn")}</span>
                  <ArrowRight size={16} />
                </Link>
              </div>
            </div>

            {/* Hero Feature Card */}
            <div className="lg:col-span-5">
              <div className="bg-white rounded-3xl p-8 space-y-6">
                <div className="flex items-center gap-3 pb-4">
                  <div className="w-10 h-10 rounded-2xl bg-[#0A2140] text-[#E4B95A] flex items-center justify-center">
                    <ShieldCheck size={20} />
                  </div>
                  <div>
                    <h3 className="ohh-serif text-lg font-semibold text-[#0A2140]">
                      {t("insurance.whyTitle")}
                    </h3>
                    <p className="text-xs text-[#8A7B5C]">
                      {t("insurance.whySub")}
                    </p>
                  </div>
                </div>

                <ul className="space-y-4 text-sm text-[#3A4657]">
                  <li className="flex items-start gap-3">
                    <div className="w-5 h-5 rounded-full bg-[#F3ECDC] text-[#0A2140] flex items-center justify-center flex-shrink-0 mt-0.5 font-bold text-xs">
                      ✓
                    </div>
                    <span>{t("insurance.why1")}</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-5 h-5 rounded-full bg-[#F3ECDC] text-[#0A2140] flex items-center justify-center flex-shrink-0 mt-0.5 font-bold text-xs">
                      ✓
                    </div>
                    <span>{t("insurance.why2")}</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <div className="w-5 h-5 rounded-full bg-[#F3ECDC] text-[#0A2140] flex items-center justify-center flex-shrink-0 mt-0.5 font-bold text-xs">
                      ✓
                    </div>
                    <span>{t("insurance.why3")}</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== Trust Strip Grid ===== */}
      <section className="bg-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                label: t("trust.verifyLabel"),
                sub: t("trust.verifySub"),
                icon: CheckCircle2,
                accentColor: "text-[#C89B3C]",
                bgIcon: "bg-[#F3ECDC]",
              },
              {
                label: t("trust.medicareLabel"),
                sub: t("trust.medicareSub"),
                icon: Award,
                accentColor: "text-[#0A2140]",
                bgIcon: "bg-[#EAEFF7]",
              },
              {
                label: t("trust.multipleLabel"),
                sub: t("trust.multipleSub"),
                icon: Layers,
                accentColor: "text-[#0A2140]",
                bgIcon: "bg-[#F3ECDC]",
              },
              {
                label: t("trust.transparentLabel"),
                sub: t("trust.transparentSub"),
                icon: SlidersHorizontal,
                accentColor: "text-[#C89B3C]",
                bgIcon: "bg-[#F7F1E6]",
              },
            ].map((item) => {
              const IconComponent = item.icon;
              return (
                <div
                  key={item.label}
                  className="group flex flex-col justify-between p-6 rounded-3xl bg-[#FBF8F2] hover:bg-[#F3ECDC]/40 transition-colors duration-300"
                >
                  <div
                    className={`w-10 h-10 rounded-2xl ${item.bgIcon} ${item.accentColor} flex items-center justify-center mb-4 transition-transform group-hover:scale-105`}
                  >
                    <IconComponent size={20} />
                  </div>

                  <div>
                    <span className="text-[11px] uppercase tracking-wider text-[#8A7B5C] font-bold block">
                      {item.sub}
                    </span>
                    <span className="ohh-serif text-base font-bold text-[#0A2140] mt-1 block">
                      {item.label}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ===== Insurance Lines Grid ===== */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16 space-y-4">
            <span className="text-xs font-bold uppercase tracking-widest text-[#C89B3C]">
              {t("grid.tag")}
            </span>
            <h2 className="ohh-serif text-3xl sm:text-4xl font-semibold text-[#0A2140]">
              {t("grid.title")}
            </h2>
            <p className="text-sm text-[#5B6B7C]">{t("grid.description")}</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {insuranceLines.map((item) => (
              <div
                key={item.key}
                className={`${item.bgClass} p-8 rounded-3xl flex flex-col justify-between space-y-6`}
              >
                <div className="space-y-4">
                  <span
                    className={`inline-block px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${item.badgeBgClass}`}
                  >
                    {t(`${item.key}.badge`)}
                  </span>

                  <h3
                    className={`ohh-serif text-xl font-bold ${item.textClass}`}
                  >
                    {t(`${item.key}.title`)}
                  </h3>

                  <p className="text-sm text-white/70 font-light leading-relaxed">
                    {t(`${item.key}.desc`)}
                  </p>
                </div>

                <div className="flex items-center justify-between text-xs text-white/50">
                  <span>{t("card.verificationRequired")}</span>
                  <span className={item.textClass}>{t("card.activePlan")}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== Notices & Disclaimer Cards ===== */}
      <section className="pb-24 pt-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Pending Notice Box */}
            <div className="bg-[#0A2140] text-white rounded-3xl p-8 sm:p-10 flex flex-col justify-between space-y-6 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-48 h-48 bg-[#C89B3C]/10 rounded-full blur-3xl pointer-events-none" />

              <div className="space-y-4 relative z-10">
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/10 text-[#E4B95A] text-xs font-bold uppercase tracking-wider">
                  <Info size={14} />
                  <span>{t("notice.badge")}</span>
                </div>

                <h3 className="ohh-serif text-2xl font-semibold text-white tracking-tight">
                  {t("notice.title")}
                </h3>

                <p className="text-white/70 text-sm leading-relaxed">
                  {t("notice.desc")}
                </p>
              </div>

              <div className="flex items-center justify-between text-xs text-white/50 relative z-10">
                <span>{t("notice.status")}</span>
                <span className="text-[#E4B95A] font-semibold">
                  {t("notice.updated")}
                </span>
              </div>
            </div>

            {/* Compliance Disclaimer Box */}
            <div className="bg-white text-[#0A2140] rounded-3xl p-8 sm:p-10 flex flex-col justify-between space-y-6">
              <div className="space-y-4">
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#F3ECDC] text-[#0A2140] text-xs font-bold uppercase tracking-wider">
                  <ShieldAlert size={14} className="text-[#C89B3C]" />
                  <span>{t("disclaimer.badge")}</span>
                </div>

                <h3 className="ohh-serif text-2xl font-semibold text-[#0A2140] tracking-tight">
                  {t("disclaimer.title")}
                </h3>

                <p className="text-[#5B6B7C] text-sm leading-relaxed">
                  {t("disclaimer.desc")}
                </p>
              </div>

              <div className="flex items-center justify-between text-xs text-[#8A93A0]">
                <span>{t("disclaimer.mandatory")}</span>
                <span className="text-[#0A2140] font-bold">
                  {t("disclaimer.standards")}
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}