"use client";

import { useState } from "react";
import { MapPin, Phone, Mail, Clock, ShieldAlert } from "lucide-react";
import { useLanguage } from "@/src/context/LanguageContext";
import content from "@/src/locales/resources/contact.json";
import { siteConfig } from "@/src/constants/siteConfig";

export default function ContactPage() {
  const { language } = useLanguage();
  const t = content[language as "en" | "es"] || content.en;

  const [formStatus, setFormStatus] = useState<"idle" | "success">("idle");
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    inquiryType: "General Inquiry",
    message: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormStatus("success");
  };

  const quickInfo = [
    {
      icon: MapPin,
      label: t.locationLabel,
      // Fixed: Accessing address directly from siteConfig, not siteConfig.contact
      lines: [
        siteConfig.address.street,
        `${siteConfig.address.city}, ${siteConfig.address.state} ${siteConfig.address.zip}`,
      ],
    },
    {
      icon: Phone,
      label: t.phoneLabel,
      lines: [`P: ${siteConfig.contact.phone}`, `F: ${siteConfig.contact.fax}`],
    },
    {
      icon: Mail,
      label: t.emailLabel,
      lines: [siteConfig.contact.email],
    },
    {
      icon: Clock,
      label: t.hoursLabel,
      lines: [siteConfig.hours[language as "en" | "es"] || siteConfig.hours.en],
      note:
        siteConfig.address.note[language as "en" | "es"] ||
        siteConfig.address.note.en,
    },
  ];

  return (
    <main className="min-h-screen bg-white text-[#3A4657]">
      {/* ===== Hero Section ===== */}
      <section className="relative bg-[#0A2140] text-white overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=2000&q=80')] bg-cover bg-center opacity-10" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 lg:pt-28 pb-32 lg:pb-40">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/15 backdrop-blur-md text-[#E4B95A] font-medium text-xs tracking-wider uppercase mb-6">
              <span className="w-2 h-2 rounded-full bg-[#E4B95A] animate-pulse" />
              {t.badge}
            </div>
            <h1 className="ohh-serif text-4xl sm:text-5xl lg:text-6xl font-semibold leading-[1.1] mb-6 tracking-tight">
              {t.titleMain}{" "}
              <span className="text-[#E4B95A]">{t.titleHighlight}</span>{" "}
              {t.titleEnd}
            </h1>
            <p className="text-lg sm:text-xl text-white/75 mb-8 leading-relaxed max-w-xl">
              {t.description}
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <a
                href={`tel:${siteConfig.contact.phoneTel}`}
                className="inline-flex items-center justify-center px-8 py-4 bg-[#E4B95A] hover:bg-[#D9A93F] text-[#0A2140] font-bold rounded-xl transition-colors"
              >
                {t.callBtn} {siteConfig.contact.phone}
              </a>
              <a
                href="#contact-form"
                className="inline-flex items-center justify-center px-8 py-4 bg-white/10 hover:bg-white/15 text-white font-semibold rounded-xl transition-colors backdrop-blur-sm"
              >
                {t.msgBtn}
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* ===== Quick Info Dock ===== */}
      <section className="relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="-mt-16 lg:-mt-20 relative z-10 bg-white rounded-[2rem] p-8 lg:p-10 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {quickInfo.map(({ icon: Icon, label, lines, note }) => (
              <div key={label} className="flex items-start gap-4">
                <div className="w-11 h-11 rounded-2xl bg-[#F3ECDC] text-[#0A2140] flex items-center justify-center flex-shrink-0">
                  <Icon size={18} />
                </div>
                <div>
                  <h4 className="text-[11px] uppercase tracking-wider text-[#8A93A0] font-semibold">
                    {label}
                  </h4>
                  <p className="text-sm font-semibold text-[#0A2140] mt-0.5 leading-snug">
                    {lines.map((line, i) => (
                      <span key={line}>
                        {line}
                        {i < lines.length - 1 && <br />}
                      </span>
                    ))}
                  </p>
                  {note && (
                    <span className="text-xs font-medium text-[#C89B3C] block mt-1">
                      {note}
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== Main Content Section: Form & Office Info ===== */}
      <section id="contact-form" className="py-16 lg:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-12 gap-8">
            {/* Left Column: Form */}
            <div className="lg:col-span-7 bg-[#FBF8F2] rounded-3xl p-8 sm:p-12">
              <div className="mb-8">
                <span className="text-[#C89B3C] font-semibold tracking-widest uppercase text-xs">
                  {t.formEyebrow}
                </span>
                <h2 className="ohh-serif text-2xl sm:text-3xl font-semibold text-[#0A2140] mt-1">
                  {t.formTitle}
                </h2>
                <p className="text-[#5B6B7C] text-sm mt-2">{t.formDesc}</p>
              </div>

              {formStatus === "success" ? (
                <div className="bg-white text-emerald-800 rounded-2xl p-6 text-center">
                  <h3 className="font-bold text-lg mb-1">{t.successTitle}</h3>
                  <p className="text-sm">{t.successDesc}</p>
                  <button
                    onClick={() => setFormStatus("idle")}
                    className="mt-4 px-6 py-2 bg-emerald-600 text-white text-xs font-bold rounded-xl hover:bg-emerald-700 transition-colors"
                  >
                    {t.sendAnother}
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid sm:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-[#3A4657] mb-2">
                        {t.fullName} <span className="text-[#C89B3C]">*</span>
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.fullName}
                        onChange={(e) =>
                          setFormData({ ...formData, fullName: e.target.value })
                        }
                        placeholder="John Doe"
                        className="w-full px-4 py-3 bg-white rounded-xl focus:outline-none focus:ring-2 focus:ring-[#E4B95A] text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-[#3A4657] mb-2">
                        {t.emailAddr} <span className="text-[#C89B3C]">*</span>
                      </label>
                      <input
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) =>
                          setFormData({ ...formData, email: e.target.value })
                        }
                        placeholder="john@example.com"
                        className="w-full px-4 py-3 bg-white rounded-xl focus:outline-none focus:ring-2 focus:ring-[#E4B95A] text-sm"
                      />
                    </div>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-[#3A4657] mb-2">
                        {t.phoneNum} <span className="text-[#C89B3C]">*</span>
                      </label>
                      <input
                        type="tel"
                        required
                        value={formData.phone}
                        onChange={(e) =>
                          setFormData({ ...formData, phone: e.target.value })
                        }
                        placeholder="(972) 000-0000"
                        className="w-full px-4 py-3 bg-white rounded-xl focus:outline-none focus:ring-2 focus:ring-[#E4B95A] text-sm"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-[#3A4657] mb-2">
                        {t.inquiryType}{" "}
                        <span className="text-[#C89B3C]">*</span>
                      </label>
                      <select
                        value={formData.inquiryType}
                        onChange={(e) =>
                          setFormData({
                            ...formData,
                            inquiryType: e.target.value,
                          })
                        }
                        className="w-full px-4 py-3 bg-white rounded-xl focus:outline-none focus:ring-2 focus:ring-[#E4B95A] text-sm"
                      >
                        <option value="General Inquiry">{t.optGeneral}</option>
                        <option value="Request a Consultation">
                          {t.optConsult}
                        </option>
                        <option value="Patient Referral">
                          {t.optReferral}
                        </option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-[#3A4657] mb-2">
                      {t.messageLabel} <span className="text-[#C89B3C]">*</span>
                    </label>
                    <textarea
                      required
                      rows={5}
                      value={formData.message}
                      onChange={(e) =>
                        setFormData({ ...formData, message: e.target.value })
                      }
                      placeholder={t.messagePlaceholder}
                      className="w-full px-4 py-3 bg-white rounded-xl focus:outline-none focus:ring-2 focus:ring-[#E4B95A] text-sm resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-4 bg-[#0A2140] hover:bg-[#123258] text-white font-bold rounded-xl transition-colors text-sm uppercase tracking-wider"
                  >
                    {t.submitReq}
                  </button>
                </form>
              )}
            </div>

            {/* Right Column: Details */}
            <div className="lg:col-span-5 space-y-6">
              <div className="bg-[#0A2140] text-white rounded-3xl p-8 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-48 h-48 bg-[#E4B95A]/10 rounded-full blur-3xl pointer-events-none" />
                <h3 className="text-xl font-bold mb-4 flex items-center gap-2 relative z-10">
                  <span className="w-3 h-3 rounded-full bg-[#E4B95A]" />
                  {t.officeNoticeTitle}
                </h3>
                <div className="space-y-4 text-sm text-white/70 relative z-10">
                  <p>
                    <strong className="text-white">{siteConfig.name}</strong>
                    <br />
                    {t.dbaText}
                  </p>
                  <p>
                    <strong className="text-white">{t.addrLabel}</strong>
                    <br />
                    {siteConfig.address.full}
                  </p>
                  <p>
                    <strong className="text-white">{t.adminHoursLabel}</strong>
                    <br />
                    {t.adminHoursText}
                  </p>
                  <div className="p-4 bg-white/10 rounded-2xl">
                    <p className="text-xs font-semibold text-[#E4B95A] uppercase tracking-wider mb-1">
                      {t.apptNoticeTitle}
                    </p>
                    <p className="text-xs text-white/80">
                      {t.apptNoticeText}{" "}
                      <strong className="text-white">{t.apptNoticeBold}</strong>
                      {t.apptNoticeEnd}
                    </p>
                  </div>
                </div>
              </div>

              <div className="bg-[#FBF8F2] rounded-3xl p-8">
                <h3 className="text-lg font-bold text-[#0A2140] mb-3">
                  {t.serviceAreaTitle}
                </h3>
                <p className="text-[#5B6B7C] text-sm leading-relaxed mb-4">
                  {t.serviceAreaText}
                </p>
                <div className="flex items-center text-xs font-bold text-[#C89B3C]">
                  <span>
                    {t.verificationHotline} {siteConfig.contact.phone}
                  </span>
                </div>
              </div>

              <div className="bg-[#F3ECDC] rounded-3xl p-8">
                <h3 className="text-lg font-bold text-[#0A2140] mb-2 flex items-center gap-2">
                  <ShieldAlert size={18} className="text-[#C89B3C]" />
                  {t.afterHoursTitle}
                </h3>
                <p className="text-[#5B6B7C] text-sm leading-relaxed mb-4">
                  {t.afterHoursText}
                </p>
                <p className="text-xs text-[#8A7B5C] italic">
                  {t.afterHoursNote}
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== Map Section ===== */}
      <section className="pb-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-[#EFE8D8] rounded-3xl overflow-hidden h-96 relative flex items-center justify-center">
            <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1524661135-423995f22d0b?auto=format&fit=crop&w=2000&q=80')] bg-cover bg-center opacity-40" />
            <div className="relative z-10 bg-white/90 backdrop-blur-md p-6 sm:p-8 rounded-2xl max-w-md text-center mx-4">
              <span className="text-[#C89B3C] font-bold text-xs uppercase tracking-wider">
                {t.mapBadge}
              </span>
              <h3 className="ohh-serif text-xl font-semibold text-[#0A2140] mt-1 mb-2">
                {t.mapTitle}
              </h3>
              <p className="text-[#5B6B7C] text-xs mb-4">{t.mapAddress}</p>
              <a
                href="https://maps.google.com/?q=3560+Quannah+Drive,+Grand+Prairie,+TX+75052"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block px-6 py-2.5 bg-[#0A2140] hover:bg-[#123258] text-white text-xs font-bold rounded-xl transition-colors"
              >
                {t.mapBtn}
              </a>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
