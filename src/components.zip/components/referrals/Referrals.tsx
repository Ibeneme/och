"use client";

import { useState } from "react";
import { Upload, CheckCircle2, Phone, Mail, Printer, ShieldCheck, ArrowRight } from "lucide-react";
import { useLanguage } from "@/src/context/LanguageContext";
import content from "@/src/locales/resources/referrals.json";
import { siteConfig } from "@/src/constants/siteConfig";

export default function ReferralsPage() {
  const { language } = useLanguage();
  const t = content[language as "en" | "es"] || content.en;

  const [submitted, setSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    patientName: "",
    dob: "",
    address: "",
    phone: "",
    emergencyContact: "",
    insuranceInfo: "",
    primaryDiagnosis: "",
    requestedServices: "Skilled Nursing",
    referringProvider: "",
    providerPhone: "",
    providerFax: "",
    dischargeDate: "",
    preferredStartDate: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <main className="min-h-screen bg-white text-[#3A4657]">
      {/* ===== Hero Section ===== */}
      <section className="relative bg-[#0A2140] text-white overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=2000&q=80"
            alt="Medical consultation"
            className="w-full h-full object-cover opacity-10"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0A2140] via-transparent to-transparent" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-28">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-white/10 text-[#E4B95A] font-medium text-xs tracking-wider uppercase mb-6">
              <span className="w-2 h-2 rounded-full bg-[#E4B95A] animate-pulse" />
              {t.badge}
            </div>
            <h1 className="ohh-serif text-4xl sm:text-5xl lg:text-6xl font-semibold leading-[1.1] mb-6 tracking-tight">
              {t.titleMain} <span className="text-[#E4B95A]">{t.titleHighlight}</span>
            </h1>
            <p className="text-lg sm:text-xl text-white/70 mb-8 leading-relaxed">
              {t.description}
            </p>
            <div className="flex flex-wrap gap-4">
              <a
                href="#referral-form"
                className="px-8 py-4 bg-[#E4B95A] hover:bg-[#D9A93F] text-[#0A2140] font-bold rounded-xl transition-all text-sm"
              >
                {t.onlineFormBtn}
              </a>
              <a
                href="#methods"
                className="px-8 py-4 bg-white/10 hover:bg-white/15 text-white font-semibold rounded-xl transition-all text-sm backdrop-blur-sm"
              >
                {t.altMethodsBtn}
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* ===== Main Content ===== */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-12 gap-12">
            {/* Sticky Sidebar */}
            <aside id="methods" className="lg:col-span-4">
              <div className="lg:sticky lg:top-10 space-y-4">
                <span className="text-[#E4B95A] font-semibold tracking-widest uppercase text-xs">
                  {t.methodsEyebrow}
                </span>
                <h2 className="ohh-serif text-xl font-semibold text-[#0A2140] mb-1">
                  {t.methodsTitle}
                </h2>
                <p className="text-[#5B6B7C] text-sm mb-2">{t.methodsDesc}</p>

                <div className="bg-white rounded-3xl p-6 flex items-start gap-4">
                  <div className="w-11 h-11 shrink-0 rounded-2xl bg-[#F3ECDC] text-[#0A2140] flex items-center justify-center">
                    <Mail size={20} />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-[#0A2140] mb-1">
                      {t.emailRefTitle}
                    </h3>
                    <a
                      href={`mailto:${siteConfig.contact.email}`}
                      className="text-sm font-bold text-[#E4B95A] hover:text-[#C89B3C] transition-colors"
                    >
                      {siteConfig.contact.email} &rarr;
                    </a>
                  </div>
                </div>

                <div className="bg-white rounded-3xl p-6 flex items-start gap-4">
                  <div className="w-11 h-11 shrink-0 rounded-2xl bg-[#F3ECDC] text-[#0A2140] flex items-center justify-center">
                    <Printer size={20} />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-[#0A2140] mb-1">
                      {t.secureFaxTitle}
                    </h3>
                    <div className="text-sm font-bold text-[#0A2140]">
                      {siteConfig.contact.fax}
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-3xl p-6 flex items-start gap-4">
                  <div className="w-11 h-11 shrink-0 rounded-2xl bg-[#F3ECDC] text-[#0A2140] flex items-center justify-center">
                    <Phone size={20} />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-[#0A2140] mb-1">
                      {t.phoneIntakeTitle}
                    </h3>
                    <a
                      href={`tel:${siteConfig.contact.phoneTel}`}
                      className="text-sm font-bold text-[#E4B95A] hover:text-[#C89B3C] transition-colors"
                    >
                      ({siteConfig.contact.phone}) &rarr;
                    </a>
                  </div>
                </div>

                <div className="bg-[#0A2140] rounded-3xl p-6">
                  <h3 className="font-bold text-sm text-white mb-1">
                    {t.pdfFormTitle}
                  </h3>
                  <p className="text-xs text-white/70 mb-4 leading-relaxed">
                    {t.pdfFormDesc}
                  </p>
                  <button
                    onClick={() => alert("Referral form download initialized.")}
                    className="w-full px-5 py-3 bg-[#E4B95A] hover:bg-[#D9A93F] text-[#0A2140] font-bold rounded-xl transition-all text-xs"
                  >
                    {t.pdfBtn}
                  </button>
                </div>
              </div>
            </aside>

            {/* Main Column */}
            <div className="lg:col-span-8 space-y-16">
              <div>
                <span className="text-[#E4B95A] font-semibold tracking-widest uppercase text-xs">
                  {t.partnerBadge}
                </span>
                <h2 className="ohh-serif text-2xl sm:text-3xl font-semibold text-[#0A2140] mt-2 mb-4">
                  {t.partnerTitle}
                </h2>
                <p className="text-[#5B6B7C] text-sm leading-relaxed mb-6">
                  {t.partnerDesc}
                </p>
                <div className="flex flex-wrap gap-3">
                  {t.partners.map((item: string) => (
                    <span
                      key={item}
                      className="inline-flex items-center gap-2 bg-white px-4 py-2.5 rounded-full text-sm font-medium text-[#3A4657]"
                    >
                      <span className="w-2 h-2 rounded-full bg-[#E4B95A]" />
                      {item}
                    </span>
                  ))}
                </div>
              </div>

              <div className="bg-white rounded-3xl p-8 sm:p-10">
                <span className="text-[#E4B95A] font-semibold tracking-widest uppercase text-xs">
                  {t.scopeBadge}
                </span>
                <h3 className="text-xl font-bold text-[#0A2140] mt-2 mb-4">
                  {t.scopeTitle}
                </h3>
                <p className="text-[#5B6B7C] text-sm mb-6">{t.scopeDesc}</p>
                <ul className="grid sm:grid-cols-2 gap-x-8 gap-y-3 text-sm text-[#3A4657]">
                  {t.scopeItems.map((item: string, idx: number) => (
                    <li
                      key={item}
                      className={`flex items-start gap-2.5 ${
                        idx === 4 ? "sm:col-span-2" : ""
                      }`}
                    >
                      <ArrowRight size={16} className="text-[#E4B95A] shrink-0 mt-1" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <span className="text-[#E4B95A] font-semibold tracking-widest uppercase text-xs">
                  {t.workflowBadge}
                </span>
                <h2 className="ohh-serif text-2xl sm:text-3xl font-semibold text-[#0A2140] mt-2 mb-4">
                  {t.workflowTitle}
                </h2>
                <p className="text-[#5B6B7C] text-sm mb-8">{t.workflowDesc}</p>

                <div className="relative pl-10">
                  <div className="absolute left-[15px] top-2 bottom-2 w-px bg-[#EFE8D8]" />
                  <div className="space-y-8">
                    {t.steps.map((step: { title: string; desc: string }, idx: number) => (
                      <div key={step.title} className="relative">
                        <div className="absolute -left-10 top-0 w-8 h-8 rounded-full bg-[#E4B95A] text-[#0A2140] flex items-center justify-center font-black text-xs">
                          {idx + 1}
                        </div>
                        <h3 className="font-bold text-[#0A2140] mb-1 text-base">
                          {step.title}
                        </h3>
                        <p className="text-sm text-[#5B6B7C] leading-relaxed max-w-xl">
                          {step.desc}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== Referral Form Section ===== */}
      <section id="referral-form" className="py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-[#FBF8F2] rounded-3xl p-8 sm:p-12">
            {submitted ? (
              <div className="text-center py-16">
                <div className="w-16 h-16 bg-[#F3ECDC] text-[#C89B3C] rounded-full flex items-center justify-center mx-auto mb-6">
                  <CheckCircle2 size={36} />
                </div>
                <h2 className="ohh-serif text-2xl font-semibold text-[#0A2140] mb-3">
                  {t.successTitle}
                </h2>
                <p className="text-[#5B6B7C] text-sm max-w-lg mx-auto mb-8 leading-relaxed">
                  {t.successDesc}
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="px-8 py-3.5 bg-[#0A2140] hover:bg-[#123258] text-white font-bold rounded-xl transition-all text-sm"
                >
                  {t.anotherBtn}
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-8">
                <div>
                  <div className="inline-flex items-center gap-2 text-xs font-bold text-[#C89B3C] uppercase tracking-widest mb-2">
                    <ShieldCheck size={16} />
                    {t.hipaaBadge}
                  </div>
                  <h2 className="ohh-serif text-2xl sm:text-3xl font-semibold text-[#0A2140] mb-2">
                    {t.formTitle}
                  </h2>
                  <p className="text-[#5B6B7C] text-sm">{t.formSubtitle}</p>
                </div>

                <div className="space-y-4">
                  <h3 className="font-bold text-sm text-[#0A2140] uppercase tracking-wider pb-2">
                    {t.sec1}
                  </h3>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-[#3A4657] mb-2">
                        {t.patName}
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. John Smith"
                        value={formData.patientName}
                        onChange={(e) =>
                          setFormData({ ...formData, patientName: e.target.value })
                        }
                        className="w-full px-4 py-3 bg-white rounded-xl text-sm text-[#3A4657] focus:outline-none focus:ring-2 focus:ring-[#E4B95A]"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-[#3A4657] mb-2">
                        {t.dob}
                      </label>
                      <input
                        type="date"
                        required
                        value={formData.dob}
                        onChange={(e) =>
                          setFormData({ ...formData, dob: e.target.value })
                        }
                        className="w-full px-4 py-3 bg-white rounded-xl text-sm text-[#3A4657] focus:outline-none focus:ring-2 focus:ring-[#E4B95A]"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-[#3A4657] mb-2">
                        {t.address}
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="Street, City, State, Zip"
                        value={formData.address}
                        onChange={(e) =>
                          setFormData({ ...formData, address: e.target.value })
                        }
                        className="w-full px-4 py-3 bg-white rounded-xl text-sm text-[#3A4657] focus:outline-none focus:ring-2 focus:ring-[#E4B95A]"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-[#3A4657] mb-2">
                        {t.phone}
                      </label>
                      <input
                        type="tel"
                        required
                        placeholder="(972) 000-0000"
                        value={formData.phone}
                        onChange={(e) =>
                          setFormData({ ...formData, phone: e.target.value })
                        }
                        className="w-full px-4 py-3 bg-white rounded-xl text-sm text-[#3A4657] focus:outline-none focus:ring-2 focus:ring-[#E4B95A]"
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-[#3A4657] mb-2">
                        {t.emerg}
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="Name, Phone, Relation"
                        value={formData.emergencyContact}
                        onChange={(e) =>
                          setFormData({ ...formData, emergencyContact: e.target.value })
                        }
                        className="w-full px-4 py-3 bg-white rounded-xl text-sm text-[#3A4657] focus:outline-none focus:ring-2 focus:ring-[#E4B95A]"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-[#3A4657] mb-2">
                        {t.insurance}
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="Insurance Provider & Policy/ID #"
                        value={formData.insuranceInfo}
                        onChange={(e) =>
                          setFormData({ ...formData, insuranceInfo: e.target.value })
                        }
                        className="w-full px-4 py-3 bg-white rounded-xl text-sm text-[#3A4657] focus:outline-none focus:ring-2 focus:ring-[#E4B95A]"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-4 pt-4">
                  <h3 className="font-bold text-sm text-[#0A2140] uppercase tracking-wider pb-2">
                    {t.sec2}
                  </h3>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-[#3A4657] mb-2">
                        {t.diag}
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="Primary diagnosis or condition"
                        value={formData.primaryDiagnosis}
                        onChange={(e) =>
                          setFormData({ ...formData, primaryDiagnosis: e.target.value })
                        }
                        className="w-full px-4 py-3 bg-white rounded-xl text-sm text-[#3A4657] focus:outline-none focus:ring-2 focus:ring-[#E4B95A]"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-[#3A4657] mb-2">
                        {t.requested}
                      </label>
                      <select
                        value={formData.requestedServices}
                        onChange={(e) =>
                          setFormData({ ...formData, requestedServices: e.target.value })
                        }
                        className="w-full px-4 py-3 bg-white rounded-xl text-sm text-[#3A4657] focus:outline-none focus:ring-2 focus:ring-[#E4B95A]"
                      >
                        <option value="Skilled Nursing">Skilled Nursing</option>
                        <option value="Physical Therapy">Physical Therapy</option>
                        <option value="Occupational Therapy">Occupational Therapy</option>
                        <option value="Speech Therapy">Speech Therapy</option>
                        <option value="Medical Social Services">Medical Social Services</option>
                        <option value="Home Health Aide">Home Health Aide</option>
                        <option value="Multiple Disciplines">Multiple Disciplines / Comprehensive Care</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-[#3A4657] mb-2">
                        {t.dischargeDate}
                      </label>
                      <input
                        type="date"
                        value={formData.dischargeDate}
                        onChange={(e) =>
                          setFormData({ ...formData, dischargeDate: e.target.value })
                        }
                        className="w-full px-4 py-3 bg-white rounded-xl text-sm text-[#3A4657] focus:outline-none focus:ring-2 focus:ring-[#E4B95A]"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-[#3A4657] mb-2">
                        {t.startDate}
                      </label>
                      <input
                        type="date"
                        required
                        value={formData.preferredStartDate}
                        onChange={(e) =>
                          setFormData({ ...formData, preferredStartDate: e.target.value })
                        }
                        className="w-full px-4 py-3 bg-white rounded-xl text-sm text-[#3A4657] focus:outline-none focus:ring-2 focus:ring-[#E4B95A]"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-4 pt-4">
                  <h3 className="font-bold text-sm text-[#0A2140] uppercase tracking-wider pb-2">
                    {t.sec3}
                  </h3>
                  <div className="grid md:grid-cols-3 gap-6">
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-[#3A4657] mb-2">
                        {t.provName}
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="Physician or Coordinator Name"
                        value={formData.referringProvider}
                        onChange={(e) =>
                          setFormData({ ...formData, referringProvider: e.target.value })
                        }
                        className="w-full px-4 py-3 bg-white rounded-xl text-sm text-[#3A4657] focus:outline-none focus:ring-2 focus:ring-[#E4B95A]"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-[#3A4657] mb-2">
                        {t.provPhone}
                      </label>
                      <input
                        type="tel"
                        required
                        placeholder="(972) 000-0000"
                        value={formData.providerPhone}
                        onChange={(e) =>
                          setFormData({ ...formData, providerPhone: e.target.value })
                        }
                        className="w-full px-4 py-3 bg-white rounded-xl text-sm text-[#3A4657] focus:outline-none focus:ring-2 focus:ring-[#E4B95A]"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-[#3A4657] mb-2">
                        {t.provFax}
                      </label>
                      <input
                        type="tel"
                        required
                        placeholder="(972) 000-0000"
                        value={formData.providerFax}
                        onChange={(e) =>
                          setFormData({ ...formData, providerFax: e.target.value })
                        }
                        className="w-full px-4 py-3 bg-white rounded-xl text-sm text-[#3A4657] focus:outline-none focus:ring-2 focus:ring-[#E4B95A]"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-4 pt-4">
                  <h3 className="font-bold text-sm text-[#0A2140] uppercase tracking-wider pb-2">
                    {t.sec4}
                  </h3>
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-[#3A4657] mb-2">
                      {t.uploadLabel}
                    </label>
                    <div className="rounded-2xl p-6 text-center transition-colors cursor-pointer bg-white">
                      <Upload size={24} className="mx-auto text-[#8A93A0] mb-2" />
                      <p className="text-xs text-[#5B6B7C] font-medium">{t.uploadPrompt}</p>
                      <p className="text-[10px] text-[#8A93A0] mt-1">{t.uploadSub}</p>
                      <input type="file" required className="hidden" accept=".pdf,.doc,.docx" />
                    </div>
                  </div>
                </div>

                <div className="pt-4">
                  <button
                    type="submit"
                    className="w-full py-4 bg-[#E4B95A] hover:bg-[#D9A93F] text-[#0A2140] font-bold rounded-xl transition-all text-sm flex items-center justify-center gap-2"
                  >
                    {t.submitReferralBtn} <ArrowRight size={16} />
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </section>
    </main>
  );
}