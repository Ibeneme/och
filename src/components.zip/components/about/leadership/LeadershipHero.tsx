"use client";

import { Award, Phone, ArrowRight, Shield } from "lucide-react";
import { useLanguage } from "@/src/context/LanguageContext";
import content from "@/src/locales/about-us/leadership.json";

export default function LeadershipHero() {
  const { language } = useLanguage();
  const t = content[language as "en" | "es"] || content.en;

  return (
    <section className="relative py-16 lg:py-20 px-6 lg:px-12 overflow-hidden bg-[#FBFAF6] text-[#0B2036]">
      <div className="max-w-7xl mx-auto grid lg:grid-cols-[1.4fr_1fr] gap-7 items-stretch">
        {/* Identity card */}
        <div className="bg-white rounded-[2rem] p-9 sm:p-11 flex flex-col gap-6 border border-[#E4E1D6]">
          <div className="inline-flex items-center gap-2 self-start bg-[#F3EBD8] text-[#8A6A26] text-xs font-bold tracking-wider uppercase px-4 py-2 rounded-full">
            <Award size={14} strokeWidth={2.25} className="text-[#B78B34]" />
            {t.eyebrow}
          </div>

          <div>
            <h1 className="ohh-serif font-semibold text-[clamp(34px,4vw,50px)] leading-[1.08] tracking-tight text-[#0B2036]">
              {t.name}{" "}
              <span className="text-[#B78B34] font-medium italic">
                {t.nameHighlight}
              </span>
            </h1>
            <p className="mt-3 text-lg font-semibold text-[#1F4B44]">
              {t.role}
            </p>
          </div>

          <svg
            viewBox="0 0 400 28"
            width="180"
            height="16"
            className="block"
            aria-hidden="true"
          >
            <path
              d="M0 14 H130 L145 3 L160 25 L175 14 H400"
              fill="none"
              stroke="#B78B34"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>

          <p className="text-[16.5px] leading-relaxed text-[#4E5F70] max-w-xl">
            {t.desc}
          </p>

          <div className="flex flex-wrap gap-3.5 mt-1">
            <a
              href="tel:9723251598"
              className="inline-flex items-center gap-2.5 bg-[#0B2036] hover:bg-[#123258] text-white font-semibold text-[14.5px] px-6.5 py-3.5 rounded-full transition-all hover:-translate-y-0.5"
            >
              <Phone size={16} strokeWidth={2.25} className="text-[#E4B95A]" />
              {t.callBtn}
            </a>
            <a
              href="/referrals"
              className="inline-flex items-center gap-2 bg-[#E7EEE9] hover:bg-[#d8e3dc] text-[#0B2036] font-semibold text-[14.5px] px-6 py-3.5 rounded-full transition-colors"
            >
              {t.referBtn}
              <ArrowRight size={16} strokeWidth={2.25} />
            </a>
          </div>
        </div>

        {/* Bento column */}
        <div className="flex flex-col gap-5">
          <div className="relative flex-1 bg-[#1F4B44] rounded-[1.75rem] p-8 overflow-hidden flex flex-col items-center justify-center text-center">
            <svg
              width="100%"
              height="64"
              viewBox="0 0 300 64"
              preserveAspectRatio="none"
              className="absolute bottom-0 left-0 opacity-[0.14]"
              aria-hidden="true"
            >
              {[
                [0, 30, 18, 34],
                [22, 18, 14, 46],
                [40, 36, 20, 28],
                [64, 10, 12, 54],
                [80, 26, 16, 38],
                [100, 4, 10, 60],
                [114, 32, 18, 32],
                [140, 16, 14, 48],
                [158, 34, 20, 30],
                [182, 8, 12, 56],
                [198, 28, 16, 36],
                [220, 20, 14, 44],
                [238, 38, 20, 26],
                [262, 14, 12, 50],
                [278, 30, 18, 34],
              ].map(([x, y, w, h]) => (
                <rect key={x} x={x} y={y} width={w} height={h} fill="#fff" />
              ))}
            </svg>

            <div className="relative w-[84px] h-[84px] mb-4">
              <svg viewBox="0 0 100 100" width="84" height="84">
                {Array.from({ length: 16 }).map((_, i) => {
                  const angle = (i / 16) * Math.PI * 2;
                  const x1 = 50 + Math.cos(angle) * 46;
                  const y1 = 50 + Math.sin(angle) * 46;
                  const x2 = 50 + Math.cos(angle) * 40;
                  const y2 = 50 + Math.sin(angle) * 40;
                  return (
                    <line
                      key={i}
                      x1={x1}
                      y1={y1}
                      x2={x2}
                      y2={y2}
                      stroke="#B78B34"
                      strokeWidth="1.5"
                      strokeLinecap="round"
                    />
                  );
                })}
                <circle
                  cx="50"
                  cy="50"
                  r="34"
                  fill="#1F4B44"
                  stroke="#B78B34"
                  strokeWidth="2"
                />
              </svg>
              <span className="absolute inset-0 flex items-center justify-center ohh-serif text-white text-[22px] font-semibold">
                AA
              </span>
            </div>

            <div className="inline-flex items-center gap-1.5 text-[#B78B34] text-xs font-bold uppercase tracking-wider mb-1.5">
              <Award size={13} strokeWidth={2.5} />
              {t.clinicalExpert}
            </div>
            <h3 className="ohh-serif text-[19px] font-semibold text-white">
              Angela Ananti, BSN, RN
            </h3>
            <p className="mt-0.5 text-[13px] text-white/70">
              {t.role.split(",")[1] || t.role}
            </p>
          </div>

          <div className="bg-white rounded-full px-6 py-5 flex items-center justify-between border border-[#E4E1D6]">
            <span className="text-[14.5px] font-semibold text-[#0B2036]">
              {t.servingBadge}
            </span>
            <Shield size={18} color="#B78B34" strokeWidth={2.25} />
          </div>
        </div>
      </div>
    </section>
  );
}