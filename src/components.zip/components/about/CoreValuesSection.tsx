"use client";

import {
  HeartHandshake,
  Award,
  UserCheck,
  ShieldCheck,
  Users,
  MapPinned,
} from "lucide-react";
import { useLanguage } from "@/src/context/LanguageContext";
import content from "@/src/locales/about-us/values.json";

function Eyebrow({ children }: { children: React.ReactNode }) {
  return (
    <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#F3ECDC] text-[#0A2140] font-semibold text-xs tracking-wider uppercase">
      <span className="w-2 h-2 rounded-full bg-[#C89B3C]" />
      {children}
    </div>
  );
}

const valueIcons = [Award, UserCheck, ShieldCheck, Users, MapPinned];

export default function CoreValuesSection() {
  const { language } = useLanguage();
  const t = content[language as "en" | "es"] || content.en;

  const FeaturedIcon = HeartHandshake;

  return (
    <section id="values" className="scroll-mt-24 p-6">
      <div className="mb-10 max-w-2xl space-y-4">
        <Eyebrow>{t.eyebrow}</Eyebrow>
        <h2 className="ohh-serif text-4xl md:text-5xl font-semibold text-[#0A2140] tracking-tight">
          {t.title}
        </h2>
        <p className="text-[#5B6B7C] text-base md:text-lg leading-relaxed">
          {t.subtitle}
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-5">
        <div className="lg:col-span-2 bg-[#0A2140] rounded-3xl p-8 md:p-10 relative overflow-hidden text-white flex flex-col justify-between min-h-[380px]">
          <div className="absolute -bottom-16 -left-16 w-56 h-56 bg-[#E4B95A]/10 rounded-full blur-3xl pointer-events-none" />
          <div className="relative z-10 space-y-6">
            <div className="flex items-start justify-between">
              <FeaturedIcon
                className="w-11 h-11 text-[#E4B95A]"
                strokeWidth={1.5}
              />
              <span className="text-xs uppercase text-slate-300 mt-1">
                {t.featuredTag}
              </span>
            </div>
            <div>
              <div className="ohh-serif text-4xl font-semibold tracking-tight leading-none">
                {t.featuredTitle}
              </div>
              <div className="mt-3 text-xs uppercase tracking-wide font-semibold text-[#E4B95A]">
                {t.featuredLabel}
              </div>
            </div>
          </div>
          <p className="relative z-10 text-slate-300 text-sm leading-relaxed pt-6 border-t border-white/10">
            {t.featuredDesc}
          </p>
        </div>

        <div className="lg:col-span-3 grid grid-cols-1 sm:grid-cols-2 gap-5">
          {t.valuesList.map((value: { title: string; description: string; tag: string; panel: string }, idx: number) => {
            const Icon = valueIcons[idx % valueIcons.length];
            const isDark = value.panel === "dark";
            return (
              <div
                key={value.title}
                className="bg-white rounded-3xl border border-[#EFE8D8] p-6 flex flex-col justify-between space-y-4"
              >
                <div className="flex items-start justify-between">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                      isDark
                        ? "bg-[#0A2140] text-[#E4B95A]"
                        : "bg-[#F3ECDC] text-[#0A2140]"
                    }`}
                  >
                    <Icon size={18} strokeWidth={1.75} />
                  </div>
                  <span className="text-[10px] uppercase text-[#8A7B5C] mt-1">
                    {value.tag}
                  </span>
                </div>
                <div>
                  <h3 className="ohh-serif text-lg font-semibold text-[#0A2140]">
                    {value.title}
                  </h3>
                  <p className="text-[#5B6B7C] text-xs leading-relaxed mt-1.5">
                    {value.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}