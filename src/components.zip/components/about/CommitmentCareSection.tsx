"use client";

import { useLanguage } from "@/src/context/LanguageContext";
import content from "@/src/locales/about-us/quality.json";

function Eyebrow({ children }: { children: React.ReactNode }) {
  return (
    <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#F3ECDC] text-[#0A2140] font-semibold text-xs tracking-wider uppercase">
      <span className="w-2 h-2 rounded-full bg-[#C89B3C]" />
      {children}
    </div>
  );
}

export default function CommitmentCareSection() {
  const { language } = useLanguage();
  const t = content[language as "en" | "es"] || content.en;

  return (
    <section
      id="quality"
      className="scroll-mt-24 ohh-sans text-[#3A4657] space-y-16"
    >
      <div className="space-y-6">
        <Eyebrow>{t.eyebrow}</Eyebrow>
        <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8">
          <h2 className="ohh-serif text-4xl md:text-5xl font-semibold text-[#0A2140] tracking-tight leading-[1.1] max-w-2xl">
            {t.titleMain} <span className="text-[#C89B3C]">{t.titleHighlight}</span>{" "}
            {t.titleEnd}
          </h2>
          <p className="text-[#5B6B7C] text-sm md:text-base max-w-md leading-relaxed">
            {t.subtitle}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white rounded-3xl p-8 border border-[#EFE8D8] flex flex-col justify-between space-y-8">
          <div className="space-y-4">
            <div className="w-10 h-10 rounded-2xl bg-[#FBF8F2] border border-[#EFE8D8] flex items-center justify-center text-[#0A2140]">
              <svg
                className="w-5 h-5"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M12 21v-8.25M15.75 21v-8.25M8.25 21v-8.25M3 9l9-6 9 6m-1.5 10.5V11.25m-15 0V19.5"
                />
              </svg>
            </div>
            <h3 className="ohh-serif text-xl font-semibold text-[#0A2140]">
              {t.card1Title}
            </h3>
            <p className="text-[#5B6B7C] text-sm leading-relaxed">
              {t.card1Desc}
            </p>
          </div>
          <div className="pt-4 border-t border-[#F0EBDD] text-xs text-[#8A7B5C] leading-relaxed">
            {t.card1Footer}
          </div>
        </div>

        <div className="bg-[#0A2140] rounded-3xl p-8 relative overflow-hidden flex flex-col justify-between text-white">
          <div className="absolute -top-20 -right-20 w-64 h-64 bg-[#E4B95A]/10 rounded-full blur-3xl pointer-events-none" />
          <div className="space-y-4 relative z-10">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#E4B95A] text-[#0A2140] text-[10px] font-bold uppercase tracking-widest">
              {t.leadershipBadge}
            </div>
            <div>
              <p className="text-xs font-semibold text-[#E4B95A]">
                {t.leaderRole}
              </p>
              <h3 className="ohh-serif text-2xl font-semibold mt-1 text-white">
                {t.leaderName}
              </h3>
            </div>
            <p className="text-slate-300 text-xs leading-relaxed pt-2">
              {t.leaderDesc}
            </p>
          </div>
          <div className="pt-6 relative z-10">
            <span className="text-xs font-semibold text-[#E4B95A] uppercase tracking-wider">
              {t.leaderTitle}
            </span>
          </div>
        </div>

        <div className="bg-white rounded-3xl p-8 border border-[#EFE8D8] flex flex-col justify-between space-y-6">
          <div className="space-y-3">
            <h3 className="ohh-serif text-xl font-semibold text-[#0A2140]">
              {t.approachTitle}
            </h3>
            <p className="text-[#5B6B7C] text-sm leading-relaxed">
              {t.approachDesc}
            </p>
          </div>
          <div className="grid grid-cols-2 gap-4 py-4 border-y border-[#F0EBDD]">
            <div>
              <p className="ohh-serif text-2xl font-bold text-[#0A2140]">
                {t.statExperience}
              </p>
              <p className="text-xs text-[#8A7B5C] font-semibold">{t.expLabel}</p>
            </div>
            <div>
              <p className="ohh-serif text-2xl font-bold text-[#C89B3C]">
                {t.statCounties}
              </p>
              <p className="text-xs text-[#8A7B5C] font-semibold">
                {t.countiesLabel}
              </p>
            </div>
          </div>
          <p className="text-xs text-[#8A7B5C] italic">{t.quote}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-8 py-8 border-y border-[#F0E9D9] text-center">
        <div>
          <p className="ohh-serif text-4xl md:text-5xl font-semibold text-[#0A2140]">
            {t.stat1Num}
          </p>
          <p className="text-xs md:text-sm text-[#5B6B7C] mt-1 font-semibold">
            {t.stat1Label}
          </p>
        </div>
        <div>
          <p className="ohh-serif text-4xl md:text-5xl font-semibold text-[#0A2140]">
            {t.stat2Num}
          </p>
          <p className="text-xs md:text-sm text-[#5B6B7C] mt-1 font-semibold">
            {t.stat2Label}
          </p>
        </div>
        <div>
          <p className="ohh-serif text-4xl md:text-5xl font-semibold text-[#C89B3C]">
            {t.stat3Num}
          </p>
          <p className="text-xs md:text-sm text-[#5B6B7C] mt-1 font-semibold">
            {t.stat3Label}
          </p>
        </div>
        <div>
          <p className="ohh-serif text-4xl md:text-5xl font-semibold text-[#0A2140]">
            {t.stat4Num}
          </p>
          <p className="text-xs md:text-sm text-[#5B6B7C] mt-1 font-semibold">
            {t.stat4Label}
          </p>
        </div>
      </div>

      <div className="bg-white rounded-3xl p-8 md:p-12 border border-[#EFE8D8] space-y-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <h3 className="ohh-serif text-3xl font-semibold text-[#0A2140] tracking-tight">
              {t.footprintTitle}
            </h3>
            <p className="text-[#5B6B7C] text-sm leading-relaxed">
              {t.footprintDesc}
            </p>
          </div>
          <div className="text-right hidden md:block">
            <span className="inline-block text-xs font-bold uppercase tracking-wider bg-[#0A2140] text-[#E4B95A] px-4 py-2 rounded-xl">
              {t.footprintPill}
            </span>
          </div>
        </div>

        <div className="w-full h-72 md:h-96 rounded-2xl overflow-hidden border border-[#EFE8D8] relative">
          <iframe
            title="Dallas-Fort Worth Metroplex Service Area"
            src="https://www.openstreetmap.org/export/embed.html?bbox=-97.70%2C32.40%2C-96.20%2C33.50&layer=mapnik&marker=32.7767%2C-96.7970"
            className="w-full h-full"
            style={{ border: 0 }}
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
          />
        </div>
      </div>
    </section>
  );
}