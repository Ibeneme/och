"use client";

import { useLanguage } from "@/src/context/LanguageContext";
import content from "@/src/locales/about-us/about.json";

function Eyebrow({ children }: { children: React.ReactNode }) {
  return (
    <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#F3ECDC] text-[#0A2140] font-semibold text-xs tracking-wider uppercase">
      <span className="w-2 h-2 rounded-full bg-[#C89B3C]" />
      {children}
    </div>
  );
}

export default function LegacyMissionSection() {
  const { language } = useLanguage();
  const t = content[language as "en" | "es"] || content.en;

  return (
    <section id="legacy" className="scroll-mt-24 ohh-sans text-[#3A4657]">
      <div className="mb-10 space-y-4">
        <Eyebrow>{t.eyebrow}</Eyebrow>
        <h2 className="ohh-serif max-w-3xl text-4xl md:text-5xl font-semibold text-[#0A2140] tracking-tight">
          {t.title}
        </h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-px bg-[#EFE8D8] rounded-3xl overflow-hidden border border-[#EFE8D8]">
        {/* Column 1 */}
        <div className="bg-white flex flex-col">
          <div
            className="bg-[#0A2140] text-white px-8 pt-10 pb-8 relative"
            style={{
              clipPath:
                "polygon(0 0, 100% 0, 100% 100%, 36px 100%, 0 calc(100% - 36px))",
            }}
          >
            <div className="flex items-start justify-between">
              <span className="ohh-serif text-6xl md:text-7xl font-semibold tracking-tighter leading-none text-[#E4B95A]">
                {t.col1Year}
              </span>
              <span className="text-xs uppercase mt-2 text-slate-300">
                {t.col1Tag}
              </span>
            </div>
            <div className="mt-8 flex items-baseline gap-1.5 text-xs uppercase tracking-wide text-slate-300">
              <span className="text-[#E4B95A]">{t.col1Kicker}</span>
              <span>{t.col1Rest}</span>
            </div>
          </div>
          <div className="px-8 py-8 flex-1 flex flex-col justify-between space-y-6">
            <p className="text-[#3A4657] text-sm md:text-base leading-relaxed">
              {t.col1Body}
            </p>
            <div className="pt-4 border-t border-[#F0EBDD] text-xs font-bold uppercase tracking-wider text-[#8A7B5C]">
              {t.col1Footer}
            </div>
          </div>
        </div>

        {/* Column 2 */}
        <div className="bg-white flex flex-col">
          <div
            className="bg-[#E4B95A] text-[#0A2140] px-8 pt-10 pb-8 relative"
            style={{
              clipPath:
                "polygon(0 0, 100% 0, 100% 100%, 36px 100%, 0 calc(100% - 36px))",
            }}
          >
            <div className="flex items-start justify-between">
              <span className="ohh-serif text-6xl md:text-7xl font-semibold tracking-tighter leading-none text-[#0A2140]">
                {t.col2Year}
              </span>
              <span className="text-xs uppercase mt-2 text-[#0A2140]/70">
                {t.col2Tag}
              </span>
            </div>
            <div className="mt-8 flex items-baseline gap-1.5 text-xs uppercase tracking-wide text-[#0A2140]/80">
              <span className="font-semibold">{t.col2Kicker}</span>
              <span>{t.col2Rest}</span>
            </div>
          </div>
          <div className="px-8 py-8 flex-1 flex flex-col justify-between space-y-6">
            <p className="text-[#3A4657] text-sm md:text-base leading-relaxed">
              {t.col2Body}
            </p>
            <div className="pt-4 border-t border-[#F0EBDD] text-xs font-bold uppercase tracking-wider text-[#C89B3C]">
              {t.col2Footer}
            </div>
          </div>
        </div>

        {/* Column 3 */}
        <div className="bg-white flex flex-col">
          <div
            className="bg-[#0A2140] text-white px-8 pt-10 pb-8 relative"
            style={{
              clipPath:
                "polygon(0 0, 100% 0, 100% 100%, 36px 100%, 0 calc(100% - 36px))",
            }}
          >
            <div className="flex items-start justify-between">
              <span className="ohh-serif text-3xl md:text-4xl font-semibold tracking-tight leading-tight">
                {t.missionTitle}
              </span>
              <span className="text-xs uppercase text-slate-300 mt-2">
                {t.missionTag}
              </span>
            </div>
            <div className="mt-8 flex items-baseline gap-1.5 text-xs uppercase tracking-wide text-white">
              <span className="font-semibold text-[#E4B95A]">
                {t.missionKicker}
              </span>
              <span>{t.missionRest}</span>
            </div>
          </div>
          <div className="px-8 py-8 flex-1 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <div>
                <h4 className="ohh-serif font-semibold text-[#0A2140] mb-1 text-sm uppercase tracking-wider">
                  {t.missionHeading}
                </h4>
                <p className="text-[#3A4657] text-xs md:text-sm leading-relaxed">
                  {t.missionText}
                </p>
              </div>
              <div>
                <h4 className="ohh-serif font-semibold text-[#0A2140] mb-1 text-sm uppercase tracking-wider">
                  {t.visionHeading}
                </h4>
                <p className="text-[#3A4657] text-xs md:text-sm leading-relaxed">
                  {t.visionText}
                </p>
              </div>
            </div>
            <div className="pt-4 border-t border-[#F0EBDD] text-xs font-bold uppercase tracking-wider text-[#0A2140]">
              {t.founderFooter}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
