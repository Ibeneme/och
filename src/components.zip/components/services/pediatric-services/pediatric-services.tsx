"use client";

import { useState } from "react";
import { Mail, Bell, CheckCircle2, ArrowRight, Phone } from "lucide-react";
import { useLanguage } from "@/src/context/LanguageContext";
import content from "@/src/locales/services/pediatric-services.json";
import { siteConfig } from "@/src/constants/siteConfig";

export default function PediatricServicesComp() {
  const { language } = useLanguage();
  const t = content[language as "en" | "es"] || content.en;

  const [emailInput, setEmailInput] = useState("");
  const [emailSubmitted, setEmailSubmitted] = useState(false);

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (emailInput.trim()) {
      setEmailSubmitted(true);
    }
  };

  return (
    <main className="min-h-screen bg-[#FBF8F2] text-[#3A4657] ohh-sans">
      {/* ===== Hero ===== */}
      <section className="relative overflow-hidden pt-12 pb-16 lg:pt-20 lg:pb-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-12 gap-12 items-center">
            <div className="lg:col-span-7 space-y-6">
              <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#F3ECDC] text-[#0A2140] font-semibold text-xs tracking-wider uppercase">
                <span className="w-2 h-2 rounded-full bg-[#C89B3C]" />
                {t.badge}
              </div>

              <div className="text-xs text-[#8A7B5C] font-medium tracking-wide">
                {t.bannerText}
              </div>

              <h1 className="ohh-serif text-4xl sm:text-5xl lg:text-6xl font-semibold text-[#0A2140] tracking-tight leading-[1.1]">
                {t.titleMain}{" "}
                <span className="text-[#C89B3C]">{t.titleHighlight}</span>
              </h1>

              <p className="text-base sm:text-lg text-[#5B6B7C] leading-relaxed max-w-2xl">
                {t.description}
              </p>

              <div className="flex flex-col sm:flex-row gap-4 pt-2">
                <a
                  href="#email-signup"
                  className="inline-flex items-center justify-center gap-2 px-7 py-3.5 bg-[#0A2140] hover:bg-[#123258] text-[#E4B95A] font-bold rounded-full transition-colors group"
                >
                  <Mail size={16} />
                  <span>{t.joinList}</span>
                  <ArrowRight
                    size={16}
                    className="transition-transform group-hover:translate-x-1"
                  />
                </a>
                <a
                  href={`tel:${siteConfig.contact.phoneTel}`}
                  className="inline-flex items-center justify-center gap-2 px-7 py-3.5 bg-[#F3ECDC] hover:bg-[#EADFC2] text-[#0A2140] font-semibold rounded-full transition-colors"
                >
                  <Phone size={16} />
                  <span>Call {siteConfig.contact.phone}</span>
                </a>
              </div>
            </div>

            <div className="lg:col-span-5">
              <div className="bg-white rounded-3xl p-2 overflow-hidden shadow-xl shadow-[#0A2140]/5">
                <div className="overflow-hidden rounded-[20px] aspect-[4/3]">
                  <img
                    src="https://images.unsplash.com/photo-1502781252888-914d6aadf720?auto=format&fit=crop&w=1000&q=80"
                    alt="Pediatric services coming soon"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-6 space-y-3">
                  <h3 className="ohh-serif text-lg font-semibold text-[#0A2140]">
                    {t.cardTitle}
                  </h3>
                  <p className="text-sm text-[#5B6B7C] leading-relaxed">
                    {t.cardDesc}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== Overview / Signup ===== */}
      <section className="bg-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-12 gap-12 items-start">
            <div className="lg:col-span-5 space-y-8">
              <div className="flex items-center gap-4 text-[#C89B3C]">
                <Bell size={28} strokeWidth={2} />
                <span className="text-xs font-bold tracking-widest uppercase text-[#8A7B5C]">
                  {t.noticeTag}
                </span>
              </div>
              <h2 className="ohh-serif text-3xl sm:text-4xl font-semibold text-[#0A2140] tracking-tight leading-snug">
                {t.noticeTitle}
              </h2>
              <p className="text-[#5B6B7C] text-base leading-relaxed">
                {t.noticeDesc}
              </p>
            </div>

            <div className="lg:col-span-7 bg-[#FBF8F2] rounded-3xl p-8 sm:p-14 space-y-10 shadow-sm">
              <div className="space-y-3">
                <span className="text-xs font-bold uppercase tracking-widest text-[#C89B3C]">
                  {t.stayInformed}
                </span>
                <h3 className="ohh-serif text-2xl font-semibold text-[#0A2140]">
                  {t.formTitle}
                </h3>
                <p className="text-sm text-[#5B6B7C] leading-relaxed">
                  {t.formDesc}
                </p>
              </div>

              <div id="email-signup">
                {emailSubmitted ? (
                  <div className="py-8 space-y-4 text-center">
                    <div className="w-12 h-12 rounded-2xl bg-[#0A2140] text-[#E4B95A] flex items-center justify-center mx-auto">
                      <CheckCircle2 size={24} />
                    </div>
                    <h4 className="ohh-serif font-semibold text-[#0A2140] text-lg">
                      {t.successHeading}
                    </h4>
                    <p className="text-xs text-[#5B6B7C] max-w-sm mx-auto">
                      {t.successMsg}{" "}
                      <span className="font-semibold text-[#0A2140]">
                        {emailInput}
                      </span>{" "}
                      {t.successSub}
                    </p>
                  </div>
                ) : (
                  <form onSubmit={handleEmailSubmit} className="space-y-6">
                    <input
                      type="email"
                      required
                      placeholder={t.emailPlaceholder}
                      value={emailInput}
                      onChange={(e) => setEmailInput(e.target.value)}
                      className="w-full px-5 py-4 bg-white rounded-2xl text-sm text-[#3A4657] placeholder-[#8A7B5C] focus:outline-none focus:ring-2 focus:ring-[#C89B3C]"
                    />
                    <button
                      type="submit"
                      className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-8 py-4 bg-[#0A2140] hover:bg-[#123258] text-[#E4B95A] font-bold rounded-full transition-colors group"
                    >
                      {t.submitBtn}
                      <ArrowRight
                        size={16}
                        className="transition-transform group-hover:translate-x-1"
                      />
                    </button>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
