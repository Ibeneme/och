"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import {
  ChevronDown,
  Menu,
  X,
  HeartHandshake,
  Phone,
  Stethoscope,
  Heart,
  Users,
  Shield,
  Briefcase,
  Activity,
  ArrowRight,
  BookOpen,
  UserCheck,
  Globe,
  Home,
  CreditCard,
  Info,
} from "lucide-react";
import { useLanguage } from "@/src/context/LanguageContext";
import { siteConfig } from "@/src/constants/siteConfig";

const SteadyLine = ({ className = "" }: { className?: string }) => (
  <svg
    viewBox="0 0 170 20"
    className={className}
    aria-hidden="true"
    fill="none"
  >
    <path
      d="M0 10 H55 L62 10 L67 2 L74 18 L80 10 L86 10 L91 6 L96 10 H170"
      stroke="#E4B95A"
      strokeWidth="1.6"
      strokeLinecap="round"
      strokeLinejoin="round"
      className="ohh-pulse-path"
    />
  </svg>
);

export default function Navbar() {
  const { language, setLanguage } = useLanguage();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeMobileDropdown, setActiveMobileDropdown] = useState<
    string | null
  >(null);
  const [isScrolled, setIsScrolled] = useState(false);
  const [langOpen, setLangOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 16);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = mobileMenuOpen ? "hidden" : "unset";
  }, [mobileMenuOpen]);

  useEffect(() => {
    if (!langOpen) return;
    const onDown = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target.closest("[data-lang-toggle]")) setLangOpen(false);
    };
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, [langOpen]);

  const toggleMobileDropdown = (name: string) => {
    setActiveMobileDropdown(activeMobileDropdown === name ? null : name);
  };

  const closeMobileMenu = () => {
    setMobileMenuOpen(false);
    setActiveMobileDropdown(null);
  };

  const t = {
    en: {
      banner:
        "One Community Home Health is a DBA of JACOP Healthcare Services, Inc. Serving Clients Since 2010",
      referPatient: "Refer a patient",
      home: "Home",
      services: "Services",
      about: "About",
      insurance: "Insurance & payment",
      resources: "Resources",
      requestCare: "Request care",
      inHomeCare: "In-home care",
      clinicalCareTitle: "Comprehensive clinical care",
      clinicalCareDesc:
        "Physician-directed healthcare, delivered with steady hands in the comfort of home.",
      scheduleAssessment: "Schedule an assessment",
      clinicalDisciplines: "Clinical disciplines",
      specialties: "Specialties",
      supportiveCare: "Supportive care",
      whoWeAre: "Who we are",
      getTeam: "Get to know our team",
      getTeamDesc:
        "Rooted in trust, led by clinicians who call this community home.",
      fullStory: "Our full story",
      support: "Support",
      guidesRes: "Guides & resources",
      guidesResDesc:
        "Forms, FAQs, and support for patients, families, and our care team.",
      browseAllRes: "Browse all resources",
      language: "Language",
    },
    es: {
      banner:
        "One Community Home Health es un DBA de JACOP Healthcare Services, Inc. Sirviendo a clientes desde 2010",
      referPatient: "Referir a un paciente",
      home: "Inicio",
      services: "Servicios",
      about: "Nosotros",
      insurance: "Seguros y pagos",
      resources: "Recursos",
      requestCare: "Solicitar atención",
      inHomeCare: "Cuidado en casa",
      clinicalCareTitle: "Atención clínica integral",
      clinicalCareDesc:
        "Atención médica dirigida por médicos, entregada con manos firmes en la comodidad del hogar.",
      scheduleAssessment: "Programar una evaluación",
      clinicalDisciplines: "Disciplinas clínicas",
      specialties: "Especialidades",
      supportiveCare: "Cuidado de apoyo",
      whoWeAre: "Quiénes somos",
      getTeam: "Conozca a nuestro equipo",
      getTeamDesc:
        "Arraigados en la confianza, dirigidos por profesionales clínicos que llaman hogar a esta comunidad.",
      fullStory: "Nuestra historia completa",
      support: "Apoyo",
      guidesRes: "Guías y recursos",
      guidesResDesc:
        "Formularios, preguntas frecuentes y apoyo para pacientes, familias y nuestro equipo de atención.",
      browseAllRes: "Ver todos los recursos",
      language: "Idioma",
    },
  }[language];

  const clinicalServices = [
    {
      href: "/services/skilled-nursing",
      label: language === "en" ? "Skilled Nursing" : "Enfermería Especializada",
      desc:
        language === "en"
          ? "24/7 registered nursing care at home"
          : "Cuidado de enfermería 24/7 en casa",
    },
    {
      href: "/services/physical-therapy",
      label: language === "en" ? "Physical Therapy" : "Fisioterapia",
      desc:
        language === "en"
          ? "Rehabilitation and mobility recovery"
          : "Rehabilitación y recuperación de movilidad",
    },
    {
      href: "/services/occupational-therapy",
      label: language === "en" ? "Occupational Therapy" : "Terapia Ocupacional",
      desc:
        language === "en"
          ? "Daily living skills adaptation"
          : "Adaptación de habilidades de la vida diaria",
    },
    {
      href: "/services/speech-therapy",
      label: language === "en" ? "Speech Therapy" : "Terapia del Habla",
      desc:
        language === "en"
          ? "Speech and swallowing therapy"
          : "Terapia de lenguaje y deglución",
    },
    {
      href: "/services/medical-social-services",
      label:
        language === "en"
          ? "Medical Social Services"
          : "Servicios Sociales Médicos",
      desc:
        language === "en"
          ? "Counseling and community support"
          : "Asesoramiento y apoyo comunitario",
    },
    {
      href: "/services/home-health-aide",
      label:
        language === "en"
          ? "Home Health Aide"
          : "Asistente de Salud en el Hogar",
      desc:
        language === "en"
          ? "Personal care and daily assistance"
          : "Cuidado personal y asistencia diaria",
    },
  ];

  const specialtyServices = [
    {
      href: "/services/wound-care",
      label: language === "en" ? "Wound care" : "Cuidado de heridas",
    },
    {
      href: "/services/chronic-disease-management",
      label:
        language === "en" ? "Chronic disease care" : "Enfermedades crónicas",
    },
    {
      href: "/services/medication-management",
      label:
        language === "en" ? "Medication management" : "Gestión de medicamentos",
    },
    {
      href: "/services/post-surgical-care",
      label:
        language === "en" ? "Post-surgical care" : "Cuidado post-quirúrgico",
    },
    {
      href: "/services/fall-prevention",
      label: language === "en" ? "Fall prevention" : "Prevención de caídas",
    },
    {
      href: "/services/veteran-care",
      label: language === "en" ? "Veteran care" : "Cuidado para veteranos",
    },
  ];

  const supportiveServices = [
    {
      href: "/services/companion-care",
      label: language === "en" ? "Companion Care" : "Cuidado de Acompañamiento",
    },
    {
      href: "/services/respite-care",
      label: language === "en" ? "Respite Care" : "Cuidado de relevo",
    },
    {
      href: "/services/daily-lifestyle-support",
      label: language === "en" ? "Daily Lifestyle Support" : "Apoyo Diario",
    },
    {
      href: "/services/adults-with-disabilities",
      label:
        language === "en"
          ? "Adults with Disabilities"
          : "Adultos con Discapacidades",
    },
    {
      href: "/services/pediatric-services",
      label: language === "en" ? "Pediatric Services" : "Servicios Pediátricos",
      badge: language === "en" ? "Coming soon" : "Próximamente",
    },
  ];

  const aboutLinks = [
    {
      href: "/about-us",
      label: language === "en" ? "About our agency" : "Sobre nuestra agencia",
      icon: Heart,
      desc:
        language === "en"
          ? "Our mission, vision, and values"
          : "Nuestra misión, visión y valores",
    },
    {
      href: "/about-us/leadership",
      label: language === "en" ? "Leadership team" : "Equipo de liderazgo",
      icon: Users,
      desc:
        language === "en"
          ? "Meet our executive leadership"
          : "Conozca a nuestro equipo ejecutivo",
    },
    {
      href: "/who-we-serve",
      label: language === "en" ? "Who we serve" : "A quién servimos",
      icon: Shield,
      desc:
        language === "en"
          ? "Seniors and the families we support"
          : "Personas mayores y familias",
    },
    {
      href: "/careers",
      label:
        language === "en" ? "Careers & hiring" : "Empleos y contrataciones",
      icon: Briefcase,
      desc:
        language === "en"
          ? "Join our team of care professionals"
          : "Únase a nuestro equipo profesional",
    },
    {
      href: "/careers/cna-home-health-aide-application",
      label:
        language === "en"
          ? "CNA / Home Health Aide Application"
          : "Solicitud CNA / Asistente",
      icon: UserCheck,
      desc:
        language === "en"
          ? "Apply to join our home health aide program"
          : "Aplique a nuestro programa",
    },
  ];

  const resourceLinks = [
    {
      href: "/resources",
      label:
        language === "en"
          ? "Patient & Family Resources"
          : "Recursos para Pacientes",
      icon: BookOpen,
      desc:
        language === "en"
          ? "Educational guides, FAQs, and forms for patients"
          : "Guías, preguntas frecuentes y formularios",
    },
    {
      href: "/employee-resources",
      label:
        language === "en" ? "Employee Resources" : "Recursos para Empleados",
      icon: UserCheck,
      desc:
        language === "en"
          ? "Handbook, HR/payroll support, EVV, and reporting instructions"
          : "Manual, soporte de recursos humanos y más",
    },
    {
      href: "/contact",
      label: language === "en" ? "Contact us" : "Contáctenos",
      icon: Phone,
      desc:
        language === "en"
          ? "Get in touch or schedule a consultation"
          : "Póngase en contacto o programe una consulta",
    },
    {
      href: "/referrals",
      label: language === "en" ? "Refer a patient" : "Referir a un paciente",
      icon: HeartHandshake,
      desc:
        language === "en"
          ? "Start a referral for someone in your care"
          : "Inicie una referencia",
    },
  ];

  const LangToggle = ({ compact = false }: { compact?: boolean }) => (
    <div className="relative" data-lang-toggle>
      <button
        type="button"
        onClick={() => setLangOpen((v) => !v)}
        aria-label="Change language"
        aria-expanded={langOpen}
        className={`inline-flex items-center gap-1.5 rounded-full border transition-all cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0A2140]/30 ${
          compact
            ? "px-2.5 py-1.5 text-[12px] border-[#E8DFCB] bg-white hover:bg-[#FBF8F2] text-[#0A2140]"
            : "px-3 py-2 text-[13px] border-[#E8DFCB] bg-[#FBF8F2] hover:bg-[#F3ECDC] text-[#0A2140]"
        }`}
      >
        <Globe size={compact ? 13 : 14} className="opacity-70 shrink-0" />
        <span className="font-semibold tracking-wide">
          {language === "en" ? "EN" : "ES"}
        </span>
        <span className="text-[14px] leading-none" aria-hidden>
          {language === "en" ? "🇺🇸" : "🇪🇸"}
        </span>
        <ChevronDown
          size={12}
          className={`opacity-50 transition-transform duration-200 ${
            langOpen ? "rotate-180" : ""
          }`}
        />
      </button>

      {langOpen && (
        <div className="absolute right-0 top-full mt-1.5 z-[70] min-w-[140px] rounded-xl border border-[#EFE8D8] bg-white py-1 shadow-lg shadow-[#0A2140]/[0.08]">
          <button
            type="button"
            onClick={() => {
              setLanguage("en");
              setLangOpen(false);
            }}
            className={`w-full flex items-center gap-2.5 px-3 py-2 text-left text-[13px] transition-colors cursor-pointer ${
              language === "en"
                ? "bg-[#F3ECDC] text-[#0A2140] font-semibold"
                : "text-[#3A4657] hover:bg-[#FBF8F2]"
            }`}
          >
            <span className="text-[15px]">🇺🇸</span>
            <span>English</span>
            {language === "en" && (
              <span className="ml-auto w-1.5 h-1.5 rounded-full bg-[#E4B95A]" />
            )}
          </button>
          <button
            type="button"
            onClick={() => {
              setLanguage("es");
              setLangOpen(false);
            }}
            className={`w-full flex items-center gap-2.5 px-3 py-2 text-left text-[13px] transition-colors cursor-pointer ${
              language === "es"
                ? "bg-[#F3ECDC] text-[#0A2140] font-semibold"
                : "text-[#3A4657] hover:bg-[#FBF8F2]"
            }`}
          >
            <span className="text-[15px]">🇪🇸</span>
            <span>Español</span>
            {language === "es" && (
              <span className="ml-auto w-1.5 h-1.5 rounded-full bg-[#E4B95A]" />
            )}
          </button>
        </div>
      )}
    </div>
  );

  return (
    <header className="w-full sticky top-0 z-50">
      {/* Top utility bar */}
      <div className="bg-[#0A2140] text-white text-[11px] sm:text-[12px] py-2 px-3 sm:px-6 md:px-8 relative z-50">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-3 min-w-0">
          <span className="inline-flex items-center gap-1.5 text-[#A8C0D4] truncate min-w-0">
            <span className="relative flex h-1.5 w-1.5 flex-shrink-0">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#7FA283] opacity-60" />
              <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-[#7FA283]" />
            </span>
            <span className="truncate">{t.banner}</span>
          </span>

          <div className="flex items-center gap-3 sm:gap-4 flex-shrink-0">
            <SteadyLine className="hidden lg:block w-12 h-3 opacity-90" />
            <Link
              href="/referrals"
              className="inline-flex items-center gap-1 text-white/75 hover:text-[#E4B95A] transition-colors font-medium group whitespace-nowrap"
            >
              <span>{t.referPatient}</span>
              <ArrowRight
                size={12}
                className="group-hover:translate-x-0.5 transition-transform"
              />
            </Link>
            <a
              href={`tel:${siteConfig.contact.phoneTel}`}
              className="hidden sm:inline-flex items-center gap-1.5 font-semibold text-[#E4B95A] hover:text-[#F1CE7F] transition-colors whitespace-nowrap"
            >
              <Phone size={13} strokeWidth={2.2} />
              <span>{siteConfig.contact.phone}</span>
            </a>
          </div>
        </div>
      </div>

      {/* Main navbar */}
      <div
        className={`px-3 sm:px-6 md:px-8 transition-all duration-300 relative z-50 bg-white border-b ${
          isScrolled
            ? "py-2.5 border-[#E8DFCB] shadow-[0_1px_12px_rgba(10,33,64,0.06)]"
            : "py-3.5 border-[#F0E9D9]"
        }`}
      >
        <nav
          className="max-w-7xl mx-auto flex items-center justify-between gap-4"
          role="navigation"
        >
          {/* Logo – no serif */}
          <Link
            href="/"
            className="flex items-center gap-2.5 sm:gap-3 group focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0A2140]/40 rounded-xl p-1 -ml-1 shrink-0"
          >
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-full bg-[#0A2140] flex items-center justify-center group-hover:bg-[#123258] transition-colors flex-shrink-0">
              <HeartHandshake
                size={18}
                className="text-[#E4B95A] sm:w-5 sm:h-5"
              />
            </div>
            <div className="flex flex-col justify-center leading-none">
              <span className="text-[#0A2140] font-semibold text-[1.15rem] sm:text-[1.35rem] tracking-tight">
                One Community
              </span>
              <span className="text-[9px] sm:text-[10px] uppercase tracking-[0.15em] sm:tracking-[0.2em] text-[#8A7B5C] font-semibold mt-0.5">
                Home Health
              </span>
            </div>
          </Link>

          {/* Desktop nav links */}
          <div className="hidden lg:flex items-center gap-0.5 xl:gap-1 flex-1 justify-center">
            <Link
              href="/"
              className="px-3.5 py-2 rounded-lg text-[13px] font-semibold text-[#3A4657] hover:text-[#0A2140] hover:bg-[#F3ECDC]/70 transition-colors"
            >
              {t.home}
            </Link>

            {/* Services Dropdown */}
            <div className="relative group">
              <button
                type="button"
                aria-expanded="false"
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-[13px] font-semibold text-[#3A4657] hover:text-[#0A2140] hover:bg-[#F3ECDC]/70 transition-colors cursor-pointer"
              >
                <span>{t.services}</span>
                <ChevronDown
                  size={14}
                  className="opacity-50 group-hover:rotate-180 transition-transform duration-300"
                />
              </button>

              <div className="absolute top-full left-1/2 -translate-x-1/2 pt-3 opacity-0 invisible pointer-events-none group-hover:opacity-100 group-hover:visible group-hover:pointer-events-auto transition-all duration-200 z-[60]">
                <div className="w-[min(880px,calc(100vw-2rem))] bg-white rounded-2xl border border-[#EFE8D8] overflow-hidden grid grid-cols-12 shadow-xl shadow-[#0A2140]/[0.06]">
                  <div className="col-span-12 lg:col-span-3 bg-[#F7F1E6] p-5 sm:p-6 flex flex-col justify-between border-b lg:border-b-0 lg:border-r border-[#EFE8D8]">
                    <div>
                      <div className="w-10 h-10 rounded-full bg-[#0A2140] flex items-center justify-center mb-5 text-[#E4B95A]">
                        <Stethoscope size={18} />
                      </div>
                      <span className="text-[10px] font-bold uppercase tracking-[0.14em] text-[#8A7B5C]">
                        {t.inHomeCare}
                      </span>
                      <h3 className="text-[1.25rem] sm:text-[1.4rem] text-[#0A2140] font-semibold mt-2.5 leading-snug">
                        {t.clinicalCareTitle}
                      </h3>
                      <p className="text-[13px] text-[#5B6B7C] mt-3 leading-relaxed">
                        {t.clinicalCareDesc}
                      </p>
                    </div>
                    <Link
                      href="/contact#consultation"
                      className="mt-6 sm:mt-8 inline-flex items-center gap-2 text-sm font-semibold text-[#0A2140] hover:text-[#123258] transition-colors group/link w-max"
                    >
                      <span className="border-b border-[#E4B95A] pb-0.5">
                        {t.scheduleAssessment}
                      </span>
                      <ArrowRight
                        size={14}
                        className="group-hover/link:translate-x-1 transition-transform"
                      />
                    </Link>
                  </div>

                  <div className="col-span-12 lg:col-span-9 p-5 sm:p-6 flex flex-col gap-5 sm:gap-6">
                    <div>
                      <div className="flex items-center gap-2 mb-3 text-[11px] font-bold text-[#0A2140] uppercase tracking-[0.12em]">
                        <span>{t.clinicalDisciplines}</span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-0.5">
                        {clinicalServices.map((item) => (
                          <Link
                            key={item.href}
                            href={item.href}
                            className="block py-2 px-2.5 rounded-lg hover:bg-[#FBF8F2] transition-colors group/item"
                          >
                            <div className="text-[13.5px] font-semibold text-[#2C3947] group-hover/item:text-[#0A2140]">
                              {item.label}
                            </div>
                            <p className="text-[11.5px] text-[#8A93A0] mt-0.5 leading-snug">
                              {item.desc}
                            </p>
                          </Link>
                        ))}
                      </div>
                    </div>

                    <div className="h-px bg-[#F0EBDD]" />

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 sm:gap-8">
                      <div>
                        <div className="flex items-center gap-2 mb-3 text-[11px] font-bold text-[#0A2140] uppercase tracking-[0.12em]">
                          <Activity size={13} className="text-[#C89B3C]" />
                          <span>{t.specialties}</span>
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {specialtyServices.map((item) => (
                            <Link
                              key={item.href}
                              href={item.href}
                              className="text-[12.5px] font-medium text-[#3A4657] hover:text-[#0A2140] bg-[#FBF8F2] hover:bg-[#F3ECDC] border border-[#F0EBDD] rounded-full px-3 py-1.5 transition-colors"
                            >
                              {item.label}
                            </Link>
                          ))}
                        </div>
                      </div>

                      <div>
                        <div className="flex items-center gap-2 mb-3 text-[11px] font-bold text-[#0A2140] uppercase tracking-[0.12em]">
                          <Heart size={13} className="text-[#C89B3C]" />
                          <span>{t.supportiveCare}</span>
                        </div>
                        <ul className="space-y-0.5">
                          {supportiveServices.map((item) => (
                            <li key={item.href}>
                              <Link
                                href={item.href}
                                className="flex items-center justify-between py-1.5 px-2.5 -mx-2.5 text-[13px] font-medium text-[#3A4657] hover:text-[#0A2140] hover:bg-[#FBF8F2] rounded-lg transition-colors"
                              >
                                <span>{item.label}</span>
                                {item.badge && (
                                  <span className="text-[10px] bg-[#F3ECDC] text-[#8A7B5C] px-2 py-0.5 rounded-md font-bold tracking-wide">
                                    {item.badge}
                                  </span>
                                )}
                              </Link>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* About Dropdown */}
            <div className="relative group">
              <button
                type="button"
                aria-expanded="false"
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-[13px] font-semibold text-[#3A4657] hover:text-[#0A2140] hover:bg-[#F3ECDC]/70 transition-colors cursor-pointer"
              >
                <span>{t.about}</span>
                <ChevronDown
                  size={14}
                  className="opacity-50 group-hover:rotate-180 transition-transform duration-300"
                />
              </button>

              <div className="absolute top-full left-0 pt-3 opacity-0 invisible pointer-events-none group-hover:opacity-100 group-hover:visible group-hover:pointer-events-auto transition-all duration-200 z-[60]">
                <div className="w-[min(560px,calc(100vw-2rem))] bg-white rounded-2xl border border-[#EFE8D8] overflow-hidden grid grid-cols-12 shadow-xl shadow-[#0A2140]/[0.06]">
                  <div className="col-span-12 sm:col-span-4 bg-[#F7F1E6] p-5 sm:p-6 flex flex-col justify-between border-b sm:border-b-0 sm:border-r border-[#EFE8D8]">
                    <div>
                      <div className="w-10 h-10 rounded-full bg-[#0A2140] flex items-center justify-center mb-5 text-[#E4B95A]">
                        <Heart size={18} />
                      </div>
                      <span className="text-[10px] font-bold uppercase tracking-[0.14em] text-[#8A7B5C]">
                        {t.whoWeAre}
                      </span>
                      <h3 className="text-[1.2rem] sm:text-[1.25rem] text-[#0A2140] font-semibold mt-2.5 leading-snug">
                        {t.getTeam}
                      </h3>
                      <p className="text-[13px] text-[#5B6B7C] mt-3 leading-relaxed">
                        {t.getTeamDesc}
                      </p>
                    </div>
                    <Link
                      href="/about-us"
                      className="mt-6 sm:mt-8 inline-flex items-center gap-2 text-sm font-semibold text-[#0A2140] hover:text-[#123258] transition-colors group/link w-max"
                    >
                      <span className="border-b border-[#E4B95A] pb-0.5">
                        {t.fullStory}
                      </span>
                      <ArrowRight
                        size={14}
                        className="group-hover/link:translate-x-1 transition-transform"
                      />
                    </Link>
                  </div>

                  <div className="col-span-12 sm:col-span-8 p-4 flex flex-col justify-center gap-0.5">
                    {aboutLinks.map((item) => (
                      <Link
                        key={item.href}
                        href={item.href}
                        className="flex items-start gap-3 p-3 rounded-xl hover:bg-[#FBF8F2] transition-colors group/sub"
                      >
                        <div className="p-2 rounded-lg bg-[#F3ECDC] text-[#0A2140] group-hover/sub:bg-[#0A2140] group-hover/sub:text-[#E4B95A] transition-colors flex-shrink-0">
                          <item.icon size={15} />
                        </div>
                        <div className="pt-0.5">
                          <div className="text-sm font-semibold text-[#2C3947] group-hover/sub:text-[#0A2140]">
                            {item.label}
                          </div>
                          <p className="text-[11.5px] text-[#8A93A0] mt-0.5 leading-snug">
                            {item.desc}
                          </p>
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <Link
              href="/insurance-payment-options"
              className="px-3.5 py-2 rounded-lg text-[13px] font-semibold text-[#3A4657] hover:text-[#0A2140] hover:bg-[#F3ECDC]/70 transition-colors whitespace-nowrap"
            >
              {t.insurance}
            </Link>

            {/* Resources Dropdown */}
            <div className="relative group">
              <button
                type="button"
                aria-expanded="false"
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-[13px] font-semibold text-[#3A4657] hover:text-[#0A2140] hover:bg-[#F3ECDC]/70 transition-colors cursor-pointer"
              >
                <span>{t.resources}</span>
                <ChevronDown
                  size={14}
                  className="opacity-50 group-hover:rotate-180 transition-transform duration-300"
                />
              </button>

              <div className="absolute top-full right-0 pt-3 opacity-0 invisible pointer-events-none group-hover:opacity-100 group-hover:visible group-hover:pointer-events-auto transition-all duration-200 z-[60]">
                <div className="w-[min(560px,calc(100vw-2rem))] bg-white rounded-2xl border border-[#EFE8D8] overflow-hidden grid grid-cols-12 shadow-xl shadow-[#0A2140]/[0.06]">
                  <div className="col-span-12 sm:col-span-4 bg-[#F7F1E6] p-5 sm:p-6 flex flex-col justify-between border-b sm:border-b-0 sm:border-r border-[#EFE8D8]">
                    <div>
                      <div className="w-10 h-10 rounded-full bg-[#0A2140] flex items-center justify-center mb-5 text-[#E4B95A]">
                        <BookOpen size={18} />
                      </div>
                      <span className="text-[10px] font-bold uppercase tracking-[0.14em] text-[#8A7B5C]">
                        {t.support}
                      </span>
                      <h3 className="text-[1.2rem] sm:text-[1.25rem] text-[#0A2140] font-semibold mt-2.5 leading-snug">
                        {t.guidesRes}
                      </h3>
                      <p className="text-[13px] text-[#5B6B7C] mt-3 leading-relaxed">
                        {t.guidesResDesc}
                      </p>
                    </div>
                    <Link
                      href="/resources"
                      className="mt-6 sm:mt-8 inline-flex items-center gap-2 text-sm font-semibold text-[#0A2140] hover:text-[#123258] transition-colors group/link w-max"
                    >
                      <span className="border-b border-[#E4B95A] pb-0.5">
                        {t.browseAllRes}
                      </span>
                      <ArrowRight
                        size={14}
                        className="group-hover/link:translate-x-1 transition-transform"
                      />
                    </Link>
                  </div>

                  <div className="col-span-12 sm:col-span-8 p-4 flex flex-col justify-center gap-0.5">
                    {resourceLinks.map((item) => (
                      <Link
                        key={item.href}
                        href={item.href}
                        className="flex items-start gap-3 p-3 rounded-xl hover:bg-[#FBF8F2] transition-colors group/sub"
                      >
                        <div className="p-2 rounded-lg bg-[#F3ECDC] text-[#0A2140] group-hover/sub:bg-[#0A2140] group-hover/sub:text-[#E4B95A] transition-colors flex-shrink-0">
                          <item.icon size={15} />
                        </div>
                        <div className="pt-0.5">
                          <div className="text-sm font-semibold text-[#2C3947] group-hover/sub:text-[#0A2140]">
                            {item.label}
                          </div>
                          <p className="text-[11.5px] text-[#8A93A0] mt-0.5 leading-snug">
                            {item.desc}
                          </p>
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right actions */}
          <div className="flex items-center gap-2 sm:gap-2.5 shrink-0">
            <div className="hidden sm:block">
              <LangToggle />
            </div>

            <Link
              href="/contact"
              className="hidden sm:inline-flex items-center gap-2 bg-[#0A2140] text-white text-[13px] font-bold px-4 md:px-5 py-2.5 rounded-full transition-all active:scale-[0.98] whitespace-nowrap hover:bg-[#123258]"
            >
              <HeartHandshake size={16} />
              <span>{t.requestCare}</span>
            </Link>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              aria-label="Toggle navigation menu"
              className="lg:hidden p-2.5 rounded-xl bg-[#F3ECDC] text-[#0A2140] hover:bg-[#EADFC2] transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[#0A2140]/40 active:scale-95 cursor-pointer"
            >
              <div className="relative w-5 h-5 flex items-center justify-center">
                <span
                  className={`absolute transition-all duration-300 ${
                    mobileMenuOpen
                      ? "rotate-90 opacity-0 scale-50"
                      : "rotate-0 opacity-100 scale-100"
                  }`}
                >
                  <Menu size={20} />
                </span>
                <span
                  className={`absolute transition-all duration-300 ${
                    mobileMenuOpen
                      ? "rotate-0 opacity-100 scale-100 text-[#C89B3C]"
                      : "-rotate-90 opacity-0 scale-50"
                  }`}
                >
                  <X size={20} />
                </span>
              </div>
            </button>
          </div>
        </nav>
      </div>

      {/* ========== MOBILE DRAWER – full children of dropdowns ========== */}
      <div
        className={`lg:hidden fixed inset-x-0 top-[32px] z-40 transition-all duration-300 ease-in-out ${
          mobileMenuOpen
            ? "opacity-100 visible pointer-events-auto"
            : "opacity-0 invisible pointer-events-none"
        }`}
        style={{ height: "100vh" }}
      >
        <div
          className={`absolute inset-0 bg-[#0A2140]/50 backdrop-blur-[3px] transition-opacity duration-300 ${
            mobileMenuOpen ? "opacity-100" : "opacity-0"
          }`}
          onClick={closeMobileMenu}
        />
        <div
          className={`absolute top-[90px] sm:top-[95px] inset-x-3 sm:inset-x-6 bg-white rounded-2xl border border-[#EFE8D8] overflow-hidden flex flex-col transition-all duration-300 transform origin-top shadow-2xl shadow-[#0A2140]/10 ${
            mobileMenuOpen
              ? "translate-y-0 scale-100 opacity-100"
              : "-translate-y-4 scale-[0.97] opacity-0"
          }`}
          style={{ maxHeight: "calc(100vh - 120px)" }}
        >
          <div className="overflow-y-auto p-3 space-y-1">
            {/* Language */}
            <div className="flex items-center justify-between px-3.5 py-2.5 mb-1 rounded-xl bg-[#F7F1E6] border border-[#EFE8D8]">
              <span className="text-[12px] font-semibold uppercase tracking-wider text-[#8A7B5C]">
                {t.language}
              </span>
              <LangToggle compact />
            </div>

            <Link
              href="/"
              onClick={closeMobileMenu}
              className="flex items-center gap-3 p-3.5 rounded-xl font-semibold text-[#2C3947] hover:bg-white transition-colors"
            >
              <div className="p-2 rounded-lg bg-[#F3ECDC] text-[#0A2140]">
                <Home size={17} />
              </div>
              {t.home}
            </Link>

            {/* Services accordion – all children shown */}
            <div className="rounded-xl overflow-hidden bg-white/40">
              <button
                type="button"
                onClick={() => toggleMobileDropdown("services")}
                className="flex justify-between items-center w-full p-3.5 font-semibold text-[#2C3947] hover:bg-white transition-colors rounded-xl cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-[#F3ECDC] text-[#0A2140]">
                    <Stethoscope size={17} />
                  </div>
                  {t.services}
                </div>
                <ChevronDown
                  size={15}
                  className={`text-[#8A7B5C] transition-transform duration-300 ${
                    activeMobileDropdown === "services" ? "rotate-180" : ""
                  }`}
                />
              </button>
              <div
                className={`overflow-hidden transition-all duration-300 ease-in-out ${
                  activeMobileDropdown === "services"
                    ? "max-h-[1400px] opacity-100 pb-3 px-2"
                    : "max-h-0 opacity-0"
                }`}
              >
                <div className="space-y-1.5 text-sm bg-white rounded-xl p-3 border border-[#F0EBDD]">
                  <p className="font-bold text-[#8A7B5C] uppercase tracking-[0.1em] text-[10px] px-2 pt-1 pb-0.5">
                    {t.clinicalDisciplines}
                  </p>
                  {clinicalServices.map((s) => (
                    <Link
                      key={s.href}
                      href={s.href}
                      onClick={closeMobileMenu}
                      className="block p-2.5 text-[#3A4657] hover:text-[#0A2140] hover:bg-[#FBF8F2] rounded-lg transition-colors"
                    >
                      <div className="font-semibold text-[13.5px]">
                        {s.label}
                      </div>
                      <div className="text-[11.5px] text-[#8A93A0]">
                        {s.desc}
                      </div>
                    </Link>
                  ))}
                  <div className="h-px w-full bg-[#EFE8D8] my-2" />
                  <p className="font-bold text-[#8A7B5C] uppercase tracking-[0.1em] text-[10px] px-2 pt-1 pb-0.5">
                    {t.specialties}
                  </p>
                  <div className="flex flex-wrap gap-1.5 px-2 pb-1">
                    {specialtyServices.map((s) => (
                      <Link
                        key={s.href}
                        href={s.href}
                        onClick={closeMobileMenu}
                        className="text-[12px] font-medium text-[#3A4657] hover:text-[#0A2140] bg-[#FBF8F2] border border-[#F0EBDD] rounded-full px-3 py-1.5 transition-colors"
                      >
                        {s.label}
                      </Link>
                    ))}
                  </div>
                  <div className="h-px w-full bg-[#EFE8D8] my-2" />
                  <p className="font-bold text-[#8A7B5C] uppercase tracking-[0.1em] text-[10px] px-2 pt-1 pb-0.5">
                    {t.supportiveCare}
                  </p>
                  {supportiveServices.map((s) => (
                    <Link
                      key={s.href}
                      href={s.href}
                      onClick={closeMobileMenu}
                      className="flex items-center justify-between p-2.5 text-[#3A4657] hover:text-[#0A2140] hover:bg-[#FBF8F2] rounded-lg font-medium transition-colors text-[13px]"
                    >
                      <span>{s.label}</span>
                      {s.badge && (
                        <span className="text-[10px] bg-[#F3ECDC] text-[#8A7B5C] px-2 py-0.5 rounded-md font-bold tracking-wide">
                          {s.badge}
                        </span>
                      )}
                    </Link>
                  ))}
                </div>
              </div>
            </div>

            {/* About accordion – all children shown */}
            <div className="rounded-xl overflow-hidden bg-white/40">
              <button
                type="button"
                onClick={() => toggleMobileDropdown("about")}
                className="flex justify-between items-center w-full p-3.5 font-semibold text-[#2C3947] hover:bg-white transition-colors rounded-xl cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-[#F3ECDC] text-[#0A2140]">
                    <Info size={17} />
                  </div>
                  {t.about}
                </div>
                <ChevronDown
                  size={15}
                  className={`text-[#8A7B5C] transition-transform duration-300 ${
                    activeMobileDropdown === "about" ? "rotate-180" : ""
                  }`}
                />
              </button>
              <div
                className={`overflow-hidden transition-all duration-300 ease-in-out ${
                  activeMobileDropdown === "about"
                    ? "max-h-[500px] opacity-100 pb-3 px-2"
                    : "max-h-0 opacity-0"
                }`}
              >
                <div className="space-y-1 text-sm bg-white rounded-xl p-2 border border-[#F0EBDD]">
                  {aboutLinks.map((a) => (
                    <Link
                      key={a.href}
                      href={a.href}
                      onClick={closeMobileMenu}
                      className="flex items-start gap-3 p-2.5 text-[#3A4657] hover:text-[#0A2140] hover:bg-[#FBF8F2] rounded-lg transition-colors group/sub"
                    >
                      <div className="p-1.5 rounded-md bg-[#F3ECDC] text-[#0A2140] group-hover/sub:bg-[#0A2140] group-hover/sub:text-[#E4B95A] transition-colors shrink-0 mt-0.5">
                        <a.icon size={14} />
                      </div>
                      <div>
                        <div className="text-[13px] font-semibold">
                          {a.label}
                        </div>
                        <div className="text-[11px] text-[#8A93A0]">
                          {a.desc}
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            </div>

            <Link
              href="/insurance-payment-options"
              onClick={closeMobileMenu}
              className="flex items-center gap-3 p-3.5 rounded-xl font-semibold text-[#2C3947] hover:bg-white transition-colors"
            >
              <div className="p-2 rounded-lg bg-[#F3ECDC] text-[#0A2140]">
                <CreditCard size={17} />
              </div>
              {t.insurance}
            </Link>

            {/* Resources accordion – all children shown */}
            <div className="rounded-xl overflow-hidden bg-white/40">
              <button
                type="button"
                onClick={() => toggleMobileDropdown("resources")}
                className="flex justify-between items-center w-full p-3.5 font-semibold text-[#2C3947] hover:bg-white transition-colors rounded-xl cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-[#F3ECDC] text-[#0A2140]">
                    <BookOpen size={17} />
                  </div>
                  {t.resources}
                </div>
                <ChevronDown
                  size={15}
                  className={`text-[#8A7B5C] transition-transform duration-300 ${
                    activeMobileDropdown === "resources" ? "rotate-180" : ""
                  }`}
                />
              </button>
              <div
                className={`overflow-hidden transition-all duration-300 ease-in-out ${
                  activeMobileDropdown === "resources"
                    ? "max-h-[400px] opacity-100 pb-3 px-2"
                    : "max-h-0 opacity-0"
                }`}
              >
                <div className="space-y-1 text-sm bg-white rounded-xl p-2 border border-[#F0EBDD]">
                  {resourceLinks.map((r) => (
                    <Link
                      key={r.href}
                      href={r.href}
                      onClick={closeMobileMenu}
                      className="flex items-start gap-3 p-2.5 text-[#3A4657] hover:text-[#0A2140] hover:bg-[#FBF8F2] rounded-lg transition-colors group/sub"
                    >
                      <div className="p-1.5 rounded-md bg-[#F3ECDC] text-[#0A2140] group-hover/sub:bg-[#0A2140] group-hover/sub:text-[#E4B95A] transition-colors shrink-0 mt-0.5">
                        <r.icon size={14} />
                      </div>
                      <div>
                        <div className="text-[13px] font-semibold">
                          {r.label}
                        </div>
                        <div className="text-[11px] text-[#8A93A0]">
                          {r.desc}
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-2 pb-3 space-y-2">
              <Link
                href="/contact#consultation"
                onClick={closeMobileMenu}
                className="flex items-center justify-center gap-2 w-full text-center bg-[#0A2140] text-white font-bold py-3.5 rounded-full transition-all active:scale-[0.98] hover:shadow-md"
              >
                <HeartHandshake size={18} />
                {t.requestCare}
              </Link>
              <a
                href={`tel:${siteConfig.contact.phoneTel}`}
                className="flex items-center justify-center gap-2 w-full text-[#0A2140] text-[14px] font-semibold px-4 py-2.5 rounded-full border border-[#E8DFCB]"
              >
                <Phone size={15} />
                {siteConfig.contact.phone}
              </a>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
